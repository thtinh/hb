-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 28, 2010 at 07:58 PM
-- Server version: 5.1.44
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hb`
--

-- --------------------------------------------------------

--
-- Table structure for table `jos_banner`
--

CREATE TABLE IF NOT EXISTS `jos_banner` (
  `bid` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL DEFAULT '0',
  `type` varchar(30) NOT NULL DEFAULT 'banner',
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `imptotal` int(11) NOT NULL DEFAULT '0',
  `impmade` int(11) NOT NULL DEFAULT '0',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `imageurl` varchar(100) NOT NULL DEFAULT '',
  `clickurl` varchar(200) NOT NULL DEFAULT '',
  `date` datetime DEFAULT NULL,
  `showBanner` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editor` varchar(50) DEFAULT NULL,
  `custombannercode` text,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `sticky` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `tags` text NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`bid`),
  KEY `viewbanner` (`showBanner`),
  KEY `idx_banner_catid` (`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `jos_banner`
--

INSERT INTO `jos_banner` (`bid`, `cid`, `type`, `name`, `alias`, `imptotal`, `impmade`, `clicks`, `imageurl`, `clickurl`, `date`, `showBanner`, `checked_out`, `checked_out_time`, `editor`, `custombannercode`, `catid`, `description`, `sticky`, `ordering`, `publish_up`, `publish_down`, `tags`, `params`) VALUES
(1, 1, '', 'I have a dream (Pic)', 'i-have-a-dream', 0, 704, 0, 'banner-top1.png', '', '2010-07-22 04:03:10', 0, 0, '0000-00-00 00:00:00', '', '', 1, '', 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'home, Hoa Binh Village', 'width=0\nheight=0'),
(2, 1, '', 'Castle in the sky', 'castle-in-the-sky', 0, 669, 0, 'banner-top2.png', '', '2010-07-10 02:39:52', 1, 0, '0000-00-00 00:00:00', '', '', 1, '', 0, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'news, album, intro', 'width=0\nheight=0'),
(3, 1, '', 'Nhịp cầu trái tim', 'nhip-cau-trai-tim', 0, 3343, 0, 'nhip-cau-trai-tim.gif', '', '2010-07-27 09:56:17', 1, 0, '0000-00-00 00:00:00', '', '', 2, '', 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 'width=270\nheight=197'),
(4, 2, '', 'Muse Group', 'muse-group', 0, 3383, 0, 'logo1.gif', '', '2010-07-15 09:42:52', 1, 0, '0000-00-00 00:00:00', '', '', 9, 'Muse Group''s short description', 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 'width=0\nheight=0'),
(5, 2, '', 'Cheap Drink AU', 'cheap-drink-au', 0, 1022, 0, 'logo2.gif', '', '2010-07-15 09:42:59', 1, 0, '0000-00-00 00:00:00', '', '', 9, 'Cheap Drink''s short description', 0, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 'width=0\nheight=0'),
(6, 2, '', 'Triple Consulting', 'triple-consulting', 0, 1022, 0, 'logo3.gif', '', '2010-07-15 09:43:05', 1, 0, '0000-00-00 00:00:00', '', '', 9, 'Triple Consulting Description', 0, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 'width=0\nheight=0'),
(7, 2, '', 'Fooboo Ltd', 'fooboo-ltd', 0, 865, 0, 'logo4.gif', '', '2010-07-15 09:43:12', 1, 0, '0000-00-00 00:00:00', '', '', 9, 'Fooboo Ltd Description', 0, 4, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 'width=0\nheight=0'),
(8, 2, '', 'Botanika Spa', 'botanika-spa', 0, 865, 0, 'logo5.gif', '', '2010-07-15 09:50:42', 1, 0, '0000-00-00 00:00:00', '', '', 9, 'Botanika Spa short description', 0, 5, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 'width=0\nheight=0'),
(9, 2, '', 'Agilo Ltd', 'agilo-ltd', 0, 3224, 0, 'logo6.gif', '', '2010-07-26 04:01:02', 1, 0, '0000-00-00 00:00:00', '', '', 9, 'Agilo Ltd short description', 1, 6, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 'width=0\nheight=0'),
(10, 2, '', 'James - Morray Ltd', 'james-morray-ltd', 0, 863, 0, 'logo7.gif', '', '2010-07-15 09:55:21', 1, 0, '0000-00-00 00:00:00', '', '', 9, 'James - Morray Ltd short description', 0, 7, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 'width=0\nheight=0'),
(11, 2, '', 'Car Find Solution Ltd', 'car-find-solution-ltd', 0, 3224, 0, 'logo8.gif', '', '2010-07-26 04:01:15', 1, 0, '0000-00-00 00:00:00', '', '', 9, 'Car Find Solution Ltd Short description', 1, 8, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 'width=0\nheight=0'),
(12, 2, '', 'Flowerbox Shop', 'flowerbox-shop', 0, 863, 0, 'logo9.gif', '', '2010-07-15 09:56:34', 1, 0, '0000-00-00 00:00:00', '', '', 9, 'Flowerbox Shop short description', 0, 9, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 'width=0\nheight=0'),
(13, 1, '', 'I have a dream (Flash)', 'i-have-a-dream', 0, 2635, 0, 'lhb_home_banner.swf', '', '2010-07-22 04:45:23', 1, 0, '0000-00-00 00:00:00', '', '', 1, '', 0, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'home, Hoa Binh Village ', 'width=950\nheight=290');

-- --------------------------------------------------------

--
-- Table structure for table `jos_bannerclient`
--

CREATE TABLE IF NOT EXISTS `jos_bannerclient` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `contact` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `extrainfo` text NOT NULL,
  `checked_out` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out_time` time DEFAULT NULL,
  `editor` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `jos_bannerclient`
--

INSERT INTO `jos_bannerclient` (`cid`, `name`, `contact`, `email`, `extrainfo`, `checked_out`, `checked_out_time`, `editor`) VALUES
(1, 'Hoa Binh Village', 'Hoa Binh Village', 'info@hoabinhvillage.org', '', 0, '00:00:00', ''),
(2, 'General Sponsors', 'General Sponsors', 'no@email.com', '', 0, '00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_bannertrack`
--

CREATE TABLE IF NOT EXISTS `jos_bannertrack` (
  `track_date` date NOT NULL,
  `track_type` int(10) unsigned NOT NULL,
  `banner_id` int(10) unsigned NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_bannertrack`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_categories`
--

CREATE TABLE IF NOT EXISTS `jos_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL DEFAULT '',
  `section` varchar(50) NOT NULL DEFAULT '',
  `image_position` varchar(30) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editor` varchar(50) DEFAULT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `count` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cat_idx` (`section`,`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `jos_categories`
--

INSERT INTO `jos_categories` (`id`, `parent_id`, `title`, `name`, `alias`, `image`, `section`, `image_position`, `description`, `published`, `checked_out`, `checked_out_time`, `editor`, `ordering`, `access`, `count`, `params`) VALUES
(1, 0, 'Top Banner', '', 'top-banner', '', 'com_banner', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, ''),
(2, 0, 'Right Banner', '', 'right-banner', '', 'com_banner', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 2, 0, 0, ''),
(3, 0, 'Thời sự - Phóng sự', '', 'thoi-su-phong-su', '', '1', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, ''),
(4, 0, 'Thông tin khoa học', '', 'thong-tin-khoa-hoc', '', '1', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 2, 0, 0, ''),
(5, 0, 'Tấm lòng vàng', '', 'tam-long-vang', '', '1', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 3, 0, 0, ''),
(6, 0, 'Ký sự', '', 'ky-su', '', '1', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 4, 0, 0, ''),
(7, 0, 'Nhịp cầu trái tim', '', 'nhip-cau-trai-tim', '', '1', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 5, 0, 0, ''),
(8, 0, 'Khác', '', 'khac', '', '2', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 6, 0, 0, ''),
(9, 0, 'Sponsor', '', 'sponsor', '', 'com_banner', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 3, 0, 0, ''),
(10, 0, 'Sổ lưu niệm', '', 'so-luu-niem', '', '6', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 6, 0, 0, ''),
(11, 0, 'Danh sách nhà tài trợ', '', 'danh-sanh-nha-tai-tro', '', '6', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 7, 0, 0, ''),
(12, 0, 'Menu Item', '', 'menu-item', '', '7', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 8, 0, 0, ''),
(13, 0, 'Frontpage', '', 'frontpage', '', '5', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 6, 0, 0, ''),
(14, 0, 'Tư liệu', '', 'phim-tu-lieu', '', '2', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 7, 0, 0, ''),
(15, 0, 'Lịch sử thành lập', '', 'lich-su-thanh-lap', '', '6', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 8, 0, 0, ''),
(16, 0, 'Các hoạt động', '', 'cac-hoat-dong', '', '6', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 9, 0, 0, ''),
(17, 0, 'Tổ chức', '', 'to-chuc', '', '6', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 10, 0, 0, ''),
(18, 0, 'Đào tạo - Nghiên cứu', '', 'dao-tao-nghien-cuu', '', '6', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 11, 0, 0, ''),
(19, 0, 'Giới thiệu', '', 'gioi-thieu', '', '6', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 12, 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_components`
--

CREATE TABLE IF NOT EXISTS `jos_components` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `link` varchar(255) NOT NULL DEFAULT '',
  `menuid` int(11) unsigned NOT NULL DEFAULT '0',
  `parent` int(11) unsigned NOT NULL DEFAULT '0',
  `admin_menu_link` varchar(255) NOT NULL DEFAULT '',
  `admin_menu_alt` varchar(255) NOT NULL DEFAULT '',
  `option` varchar(50) NOT NULL DEFAULT '',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `admin_menu_img` varchar(255) NOT NULL DEFAULT '',
  `iscore` tinyint(4) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `enabled` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `parent_option` (`parent`,`option`(32))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=72 ;

--
-- Dumping data for table `jos_components`
--

INSERT INTO `jos_components` (`id`, `name`, `link`, `menuid`, `parent`, `admin_menu_link`, `admin_menu_alt`, `option`, `ordering`, `admin_menu_img`, `iscore`, `params`, `enabled`) VALUES
(1, 'Banners', '', 0, 0, '', 'Banner Management', 'com_banners', 0, 'js/ThemeOffice/component.png', 0, 'track_impressions=0\ntrack_clicks=0\ntag_prefix=\n\n', 1),
(2, 'Banners', '', 0, 1, 'option=com_banners', 'Active Banners', 'com_banners', 1, 'js/ThemeOffice/edit.png', 0, '', 1),
(3, 'Clients', '', 0, 1, 'option=com_banners&c=client', 'Manage Clients', 'com_banners', 2, 'js/ThemeOffice/categories.png', 0, '', 1),
(4, 'Web Links', 'option=com_weblinks', 0, 0, '', 'Manage Weblinks', 'com_weblinks', 0, 'js/ThemeOffice/component.png', 0, 'show_comp_description=1\ncomp_description=\nshow_link_hits=1\nshow_link_description=1\nshow_other_cats=1\nshow_headings=1\nshow_page_title=1\nlink_target=0\nlink_icons=\n\n', 1),
(5, 'Links', '', 0, 4, 'option=com_weblinks', 'View existing weblinks', 'com_weblinks', 1, 'js/ThemeOffice/edit.png', 0, '', 1),
(6, 'Categories', '', 0, 4, 'option=com_categories&section=com_weblinks', 'Manage weblink categories', '', 2, 'js/ThemeOffice/categories.png', 0, '', 1),
(7, 'Contacts', 'option=com_contact', 0, 0, '', 'Edit contact details', 'com_contact', 0, 'js/ThemeOffice/component.png', 1, 'contact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_fax=\nicon_misc=\nshow_headings=1\nshow_position=1\nshow_email=0\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nbannedEmail=\nbannedSubject=\nbannedText=\nsession=1\ncustomReply=0\n\n', 1),
(8, 'Contacts', '', 0, 7, 'option=com_contact', 'Edit contact details', 'com_contact', 0, 'js/ThemeOffice/edit.png', 1, '', 1),
(9, 'Categories', '', 0, 7, 'option=com_categories&section=com_contact_details', 'Manage contact categories', '', 2, 'js/ThemeOffice/categories.png', 1, 'contact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_fax=\nicon_misc=\nshow_headings=1\nshow_position=1\nshow_email=0\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nbannedEmail=\nbannedSubject=\nbannedText=\nsession=1\ncustomReply=0\n\n', 1),
(10, 'Polls', 'option=com_poll', 0, 0, 'option=com_poll', 'Manage Polls', 'com_poll', 0, 'js/ThemeOffice/component.png', 0, '', 1),
(11, 'News Feeds', 'option=com_newsfeeds', 0, 0, '', 'News Feeds Management', 'com_newsfeeds', 0, 'js/ThemeOffice/component.png', 0, '', 1),
(12, 'Feeds', '', 0, 11, 'option=com_newsfeeds', 'Manage News Feeds', 'com_newsfeeds', 1, 'js/ThemeOffice/edit.png', 0, 'show_headings=1\nshow_name=1\nshow_articles=1\nshow_link=1\nshow_cat_description=1\nshow_cat_items=1\nshow_feed_image=1\nshow_feed_description=1\nshow_item_description=1\nfeed_word_count=0\n\n', 1),
(13, 'Categories', '', 0, 11, 'option=com_categories&section=com_newsfeeds', 'Manage Categories', '', 2, 'js/ThemeOffice/categories.png', 0, '', 1),
(14, 'User', 'option=com_user', 0, 0, '', '', 'com_user', 0, '', 1, '', 1),
(15, 'Search', 'option=com_search', 0, 0, 'option=com_search', 'Search Statistics', 'com_search', 0, 'js/ThemeOffice/component.png', 1, 'enabled=0\n\n', 1),
(16, 'Categories', '', 0, 1, 'option=com_categories&section=com_banner', 'Categories', '', 3, '', 1, '', 1),
(17, 'Wrapper', 'option=com_wrapper', 0, 0, '', 'Wrapper', 'com_wrapper', 0, '', 1, '', 1),
(18, 'Mail To', '', 0, 0, '', '', 'com_mailto', 0, '', 1, '', 1),
(19, 'Media Manager', '', 0, 0, 'option=com_media', 'Media Manager', 'com_media', 0, '', 1, 'upload_extensions=bmp,csv,doc,epg,gif,ico,jpg,odg,odp,ods,odt,pdf,png,ppt,swf,txt,xcf,xls,BMP,CSV,DOC,EPG,GIF,ICO,JPG,ODG,ODP,ODS,ODT,PDF,PNG,PPT,SWF,TXT,XCF,XLS,xlsm\nupload_maxsize=10000000\nfile_path=images\nimage_path=images/stories\nrestrict_uploads=1\nallowed_media_usergroup=3\ncheck_mime=1\nimage_extensions=bmp,gif,jpg,png\nignore_extensions=\nupload_mime=image/jpeg,image/gif,image/png,image/bmp,application/x-shockwave-flash,application/msword,application/excel,application/pdf,application/powerpoint,text/plain,application/x-zip\nupload_mime_illegal=text/html\nenable_flash=0\n\n', 1),
(20, 'Articles', 'option=com_content', 0, 0, '', '', 'com_content', 0, '', 1, 'show_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\nfeed_summary=0\n\n', 1),
(21, 'Configuration Manager', '', 0, 0, '', 'Configuration', 'com_config', 0, '', 1, '', 1),
(22, 'Installation Manager', '', 0, 0, '', 'Installer', 'com_installer', 0, '', 1, '', 1),
(23, 'Language Manager', '', 0, 0, '', 'Languages', 'com_languages', 0, '', 1, '', 1),
(24, 'Mass mail', '', 0, 0, '', 'Mass Mail', 'com_massmail', 0, '', 1, 'mailSubjectPrefix=\nmailBodySuffix=\n\n', 1),
(25, 'Menu Editor', '', 0, 0, '', 'Menu Editor', 'com_menus', 0, '', 1, '', 1),
(27, 'Messaging', '', 0, 0, '', 'Messages', 'com_messages', 0, '', 1, '', 1),
(28, 'Modules Manager', '', 0, 0, '', 'Modules', 'com_modules', 0, '', 1, '', 1),
(29, 'Plugin Manager', '', 0, 0, '', 'Plugins', 'com_plugins', 0, '', 1, '', 1),
(30, 'Template Manager', '', 0, 0, '', 'Templates', 'com_templates', 0, '', 1, '', 1),
(31, 'User Manager', '', 0, 0, '', 'Users', 'com_users', 0, '', 1, 'allowUserRegistration=1\nnew_usertype=Registered\nuseractivation=1\nfrontend_userparams=1\n\n', 1),
(32, 'Cache Manager', '', 0, 0, '', 'Cache', 'com_cache', 0, '', 1, '', 1),
(33, 'Control Panel', '', 0, 0, '', 'Control Panel', 'com_cpanel', 0, '', 1, '', 1),
(34, 'VXGAjax', '', 0, 0, '', 'VXGAjax', 'com_vxgajax', 0, '', 0, '', 1),
(36, 'JA Comment', 'option=com_jacomment', 0, 0, 'option=com_jacomment', 'JA Comment', 'com_jacomment', 0, 'components/com_jacomment/asset/images/jacomment.png', 0, '', 1),
(41, 'kero', '', 0, 0, '', 'kero', 'com_kero', 0, '', 0, '', 1),
(57, 'Gallery', 'option=com_phocagallery', 0, 0, 'option=com_phocagallery', 'Gallery', 'com_phocagallery', 0, 'components/com_phocagallery/assets/images/icon-16-pg-menu-cat.png', 0, '', 1),
(58, 'Control Panel', '', 0, 57, 'option=com_phocagallery', 'Control Panel', 'com_phocagallery', 0, 'components/com_phocagallery/assets/images/icon-16-pg-control-panel.png', 0, '', 1),
(59, 'Images', '', 0, 57, 'option=com_phocagallery&view=phocagallerys', 'Images', 'com_phocagallery', 1, 'components/com_phocagallery/assets/images/icon-16-pg-menu-gal.png', 0, '', 1),
(60, 'Categories', '', 0, 57, 'option=com_phocagallery&view=phocagallerycs', 'Categories', 'com_phocagallery', 2, 'components/com_phocagallery/assets/images/icon-16-pg-menu-cat.png', 0, '', 1),
(64, 'Category Comments', '', 0, 57, 'option=com_phocagallery&view=phocagallerycos', 'Category Comments', 'com_phocagallery', 6, 'components/com_phocagallery/assets/images/icon-16-pg-menu-comment.png', 0, '', 1),
(65, 'Image Comments', '', 0, 57, 'option=com_phocagallery&view=phocagallerycoimgs', 'Image Comments', 'com_phocagallery', 7, 'components/com_phocagallery/assets/images/icon-16-pg-menu-comment-img.png', 0, '', 1),
(66, 'Custom Properties', 'option=com_customproperties', 0, 0, 'option=com_customproperties', 'Custom Properties', 'com_customproperties', 0, 'components/com_customproperties/images/customproperties.png', 0, '', 1),
(67, 'Manage Custom Properties', '', 0, 66, 'option=com_customproperties&controller=fields', 'Manage Custom Properties', 'com_customproperties', 0, 'components/com_customproperties/images/editcp.png', 0, '', 1),
(68, 'Assign Custom Properties', '', 0, 66, 'option=com_customproperties&controller=assign', 'Assign Custom Properties', 'com_customproperties', 1, 'components/com_customproperties/images/assign.png', 0, '', 1),
(69, 'Utilities', '', 0, 66, 'option=com_customproperties&controller=utilities', 'Utilities', 'com_customproperties', 2, 'components/com_customproperties/images/controlpanel.png', 0, '', 1),
(70, 'Config', '', 0, 66, 'option=com_customproperties&task=configure&controller=cpanel', 'Config', 'com_customproperties', 3, 'components/com_customproperties/images/config.png', 0, '', 1),
(71, 'About', '', 0, 66, 'option=com_customproperties&task=about&controller=cpanel', 'About', 'com_customproperties', 4, 'components/com_customproperties/images/customproperties.png', 0, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `jos_contact_details`
--

CREATE TABLE IF NOT EXISTS `jos_contact_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `con_position` varchar(255) DEFAULT NULL,
  `address` text,
  `suburb` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `postcode` varchar(100) DEFAULT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `misc` mediumtext,
  `image` varchar(255) DEFAULT NULL,
  `imagepos` varchar(20) DEFAULT NULL,
  `email_to` varchar(255) DEFAULT NULL,
  `default_con` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `mobile` varchar(255) NOT NULL DEFAULT '',
  `webpage` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_contact_details`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_content`
--

CREATE TABLE IF NOT EXISTS `jos_content` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `title_alias` varchar(255) NOT NULL DEFAULT '',
  `introtext` mediumtext NOT NULL,
  `fulltext` mediumtext NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `sectionid` int(11) unsigned NOT NULL DEFAULT '0',
  `mask` int(11) unsigned NOT NULL DEFAULT '0',
  `catid` int(11) unsigned NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` text NOT NULL,
  `urls` text NOT NULL,
  `attribs` text NOT NULL,
  `version` int(11) unsigned NOT NULL DEFAULT '1',
  `parentid` int(11) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `access` int(11) unsigned NOT NULL DEFAULT '0',
  `hits` int(11) unsigned NOT NULL DEFAULT '0',
  `metadata` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_section` (`sectionid`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`state`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=96 ;

--
-- Dumping data for table `jos_content`
--

INSERT INTO `jos_content` (`id`, `title`, `alias`, `title_alias`, `introtext`, `fulltext`, `state`, `sectionid`, `mask`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `parentid`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`) VALUES
(1, 'Far far away', 'far-far-away', '', '<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>\r\n<p><img src="images/stories/food/bread.jpg" border="0" /></p>\r\n<p> </p>\r\n', '\r\n<h4>Heading 4</h4>\r\n<p>It is a paradisematic country, in which roasted parts of sentences fly into your mouth. Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar.<br /><br />The Big Oxmox advised her not to do so, because there were thousands of bad Commas, wild Question Marks and devious Semikoli, but the Little Blind Text didn’t listen. She packed her seven versalia, put her initial into the belt and made herself on the way.<br /><br />When she reached the first hills of the Italic Mountains, she had a last view back on the skyline of her hometown Bookmarksgrove, the headline of Alphabet Village and the subline of her own road, the Line Lane. Pityful a rethoric question ran over her cheek, then she continued her way. On her way she met a copy.<br /><br />The copy warned the Little Blind Text, that where it came from it would have been rewritten a thousand times and everything that was left from its origin would be the word "and" and the Little Blind Text should turn around and return to its own, safe country.</p>\r\n<h4>Heading 4</h4>\r\n<p>But nothing the copy said could convince her and so it didn’t take long until a few insidious Copy Writers ambushed her, made her drunk with Longe and Parole and dragged her into their agency, where they abused her for their projects again and again. And if she hasn’t been rewritten, then they are still using her.<br /><br />Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth.<br /><br />Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar. The Big Oxmox advised her not to do so, because there were thousands of bad Commas, wild Question Marks and devious Semikoli, but the Little Blind Text didn’t listen. She packed her seven versalia, put her initial into the belt and made herself on the way. When she reached the first hills of the Italic Mountains, she had a last view back on the skyline of her hometown Bookmarksgrove, the headline of Alphabet Village and the subline</p>\r\n<p> </p>', 1, 1, 0, 3, '2010-07-13 08:28:00', 62, '', '2010-07-13 08:38:00', 62, 0, '0000-00-00 00:00:00', '2010-07-13 08:28:00', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 4, 0, 2, 'news', '', 0, 17, 'robots=\nauthor='),
(2, 'Werther ', 'werther-', '', '<p>A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart. I am alone, and feel the charm of existence in this spot, which was created for the bliss of souls like mine. I am so happy, my dear friend, so absorbed in the exquisite sense of mere tranquil existence, that I neglect my talents.</p>\r\n<p><img src="images/stories/food/bun.jpg" border="0" /></p>\r\n', '\r\n<p>I should be incapable of drawing a single stroke at the present moment; and yet I feel that I never was a greater artist than now.<br /><br />When, while the lovely valley teems with vapour around me, and the meridian sun strikes the upper surface of the impenetrable foliage of my trees, and but a few stray gleams steal into the inner sanctuary, I throw myself down among the tall grass by the trickling stream; and, as I lie close to the earth, a thousand unknown plants are noticed by me: when I hear the buzz of the little world among the stalks, and grow familiar with the countless indescribable forms of the insects and flies, then I feel the presence of the Almighty, who formed us in his own image, and the breath of that universal love which bears and sustains us, as it floats around us in an eternity of bliss; and then, my friend, when darkness overspreads my eyes, and heaven and earth seem to dwell in my soul and absorb its power, like the form of a beloved mistress, then I often think with longing, Oh, would I could describe these conceptions, could impress upon paper all that is living so full and warm within me, that it might be the mirror of my soul, as my soul is the mirror of the infinite God!</p>\r\n<p> </p>\r\n<h4>Heading 4</h4>\r\n<p>O my friend -- but it is too much for my strength -- I sink under the weight of the splendour of these visions! A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.<br /><br />I am alone, and feel the charm of existence in this spot, which was created for the bliss of souls like mine. I am so happy, my dear friend, so absorbed in the exquisite sense of mere tranquil existence, that I neglect my talents.<br /><br />I should be incapable of drawing a single stroke at the present moment; and yet I feel that I never was a greater artist than now. When, while the lovely valley teems with vapour around me, and the meridian sun strikes the upper surface of the impenetrable foliage of my trees, and but a few stray gleams steal into the inner sanctuary, I throw myself down among the tall grass by the trickling stream; and, as I lie close to the earth, a thousand unknown plants are noticed by me: when I hear the buzz of the little world among the stalks, and grow familiar with the</p>\r\n<p> </p>', 1, 1, 0, 3, '2010-07-13 09:28:25', 62, '', '2010-07-13 09:31:59', 62, 0, '0000-00-00 00:00:00', '2010-07-13 09:28:25', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 2, 0, 1, '', '', 0, 13, 'robots=\nauthor='),
(3, 'Shalala - Hotaru', 'shalala-hotaru', '', '<table border="0">\r\n<tbody>\r\n<tr>\r\n<td><span>{flv}Shalala_Hotaru{/flv}</span></td>\r\n<td valign="top">Lorem ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean  commodo ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus  et magnis dis parturient montes, nascetur ridiculus mus.  Donec quam  felis, ultricies nec, pellentesque eu, pretium quis, sem.  Nulla  consequat massa quis enim.  Donec pede justo, fringilla vel, aliquet  nec, vulputate eget, arcu.  In enim justo, rhoncus ut, imperdiet a,  venenatis vitae, justo.</td>\r\n</tr>\r\n<tr>\r\n<td><strong>Nội dung:</strong> Aenean imperdiet.  Etiam</td>\r\n<td></td>\r\n</tr>\r\n<tr>\r\n<td>Duis leo.  Sed fringilla mauris sit amet nibh.  Donec sodales sagittis  magna.  Sed consequat, leo eget bibendum sodales, augue velit cursus  nunc</td>\r\n<td></td>\r\n</tr>\r\n</tbody>\r\n</table>', '', 1, 2, 0, 8, '2010-07-13 11:03:30', 62, '', '2010-08-26 16:43:29', 62, 0, '0000-00-00 00:00:00', '2010-07-13 11:03:30', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 6, 0, 2, '', '', 0, 258, 'robots=\nauthor='),
(4, 'Pain...', 'pain', '', '<p>{youtube}9K4qZIGWb04{/youtube}</p>', '', 1, 2, 0, 8, '2010-07-13 11:21:59', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-07-13 11:21:59', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 1, '', '', 0, 2, 'robots=\nauthor='),
(5, 'Tấm lòng vàng', 'tam-long-vang', '', '<p style="margin:0">{loadposition sponsors}</p>\r\n<p style="margin:0">{loadposition sponsorslist}</p>', '', 1, 1, 0, 5, '2010-07-16 09:31:20', 62, '', '2010-08-24 04:05:59', 62, 0, '0000-00-00 00:00:00', '2010-07-16 09:31:20', '0000-00-00 00:00:00', '', '', 'show_title=0\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=0\nshow_print_icon=0\nshow_email_icon=0\nlanguage=\nkeyref=\nreadmore=', 9, 0, 1, 'news', '', 0, 677, 'robots=\nauthor='),
(6, 'Liên hệ', 'lien-he', '', '<div id="map"><img src="images/stories/map.png" border="0" /></div>\r\n<div id="information">\r\n<div>\r\n<table border="0">\r\n<tbody>\r\n<tr>\r\n<td>\r\n<div id="address"><strong><span class="textstyle1">Làng Hòa Bình Từ Dũ</span></strong> <br /> <span style="font-weight: bold;"><span class="textstyle2">Địa chỉ</span>: </span> 284 Cống Quỳnh, Quận 1, Tp. Hồ Chí Minh, Việt Nam.  <br /> <span style="font-weight: bold;"><span class="textstyle2">Điện thoại:</span> </span> (84 8) 5404 2959 - (84 8) 3839 1229  <br /> <span style="font-weight: bold;"><span class="textstyle2">Email</span>: </span><span class="email"> info@hoabinhvillage.org</span></div>\r\n</td>\r\n<td>\r\n<div id="person"><strong><span class="textstyle2" style="font-weight: bold;">Ths.BS. NGUYỄN THỊ PHƯƠNG TẦN</span></strong> <br /> <span style="font-weight: bold;"><span class="textstyle2">ĐT:</span> </span> (84 8) 0903 745 999 <br /> <span style="font-weight: bold;"><span class="textstyle2">Email</span>: </span><span class="email">dr.phuongtan@hoabinhvillage.org</span></div>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td></td>\r\n<td>\r\n<div><span class="email"><img src="images/stories/line.jpg" border="0" /></span></div>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td></td>\r\n<td>\r\n<div id="person"><strong><span class="textstyle2">NGUYỄN ĐỨC</span></strong> <br /> <span style="font-weight: bold;"><span class="textstyle2">ĐT</span>: </span> (84 8) 0907 400 897 <br /> <span style="font-weight: bold;"><span class="textstyle2">Email:</span> </span><span class="email">duc.nihon@hoabinhvillage.org</span></div>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</div>\r\n</div>\r\n<p style="margin:0;padding:0">{loadposition contact-form}</p>', '', 1, 7, 0, 12, '2010-08-07 02:09:50', 62, '', '2010-08-26 14:32:09', 62, 0, '0000-00-00 00:00:00', '2010-08-07 02:09:50', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 23, 0, 4, '', '', 0, 386, 'robots=\nauthor='),
(7, 'nhip cau trai tim 8', 'nhip-cau-trai-tim-8', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Aenean imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar, hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.  Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Etiam sit amet orci eget eros faucibus tincidunt.  Duis leo.  Sed  fringilla mauris sit amet nibh.  Donec sodales sagittis magna.  Sed  consequat, leo eget bibendum sodales, augue velit cursus nunc, quis  gravida magna mi a libero.  Fusce vulputate eleifend sapien.  Vestibulum  purus quam, scelerisque ut, mollis sed, nonummy id, metus.  Nullam  accumsan lorem in dui.  Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.  Praesent  adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy  metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n</div>', '', 1, 1, 0, 7, '2010-08-11 06:51:12', 62, '', '2010-08-11 06:54:57', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 7, 0, 8, '', '', 0, 0, 'robots=\nauthor='),
(8, 'nhip cau trai tim 7', 'nhip-cau-trai-tim-7', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Aenean imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar, hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.  Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Etiam sit amet orci eget eros faucibus tincidunt.  Duis leo.  Sed  fringilla mauris sit amet nibh.  Donec sodales sagittis magna.  Sed  consequat, leo eget bibendum sodales, augue velit cursus nunc, quis  gravida magna mi a libero.  Fusce vulputate eleifend sapien.  Vestibulum  purus quam, scelerisque ut, mollis sed, nonummy id, metus.  Nullam  accumsan lorem in dui.  Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.  Praesent  adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy  metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n</div>', '', 1, 1, 0, 7, '2010-08-11 06:51:12', 62, '', '2010-08-11 06:54:42', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 2, 0, 7, '', '', 0, 0, 'robots=\nauthor='),
(9, 'nhip cau trai tim 6', 'nhip-cau-trai-tim-6', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Aenean imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar, hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.  Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Etiam sit amet orci eget eros faucibus tincidunt.  Duis leo.  Sed  fringilla mauris sit amet nibh.  Donec sodales sagittis magna.  Sed  consequat, leo eget bibendum sodales, augue velit cursus nunc, quis  gravida magna mi a libero.  Fusce vulputate eleifend sapien.  Vestibulum  purus quam, scelerisque ut, mollis sed, nonummy id, metus.  Nullam  accumsan lorem in dui.  Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.  Praesent  adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy  metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n</div>', '', 1, 1, 0, 7, '2010-08-11 06:51:12', 62, '', '2010-08-11 06:54:33', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 6, '', '', 0, 0, 'robots=\nauthor='),
(10, 'nhip cau trai tim 5', 'nhip-cau-trai-tim-5', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Aenean imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar, hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.  Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Etiam sit amet orci eget eros faucibus tincidunt.  Duis leo.  Sed  fringilla mauris sit amet nibh.  Donec sodales sagittis magna.  Sed  consequat, leo eget bibendum sodales, augue velit cursus nunc, quis  gravida magna mi a libero.  Fusce vulputate eleifend sapien.  Vestibulum  purus quam, scelerisque ut, mollis sed, nonummy id, metus.  Nullam  accumsan lorem in dui.  Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.  Praesent  adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy  metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n</div>', '', 1, 1, 0, 7, '2010-08-11 06:51:12', 62, '', '2010-08-11 06:54:21', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 5, '', '', 0, 0, 'robots=\nauthor='),
(11, 'nhip cau trai tim 2', 'nhip-cau-trai-tim-2', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Aenean imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar, hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.  Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Etiam sit amet orci eget eros faucibus tincidunt.  Duis leo.  Sed  fringilla mauris sit amet nibh.  Donec sodales sagittis magna.  Sed  consequat, leo eget bibendum sodales, augue velit cursus nunc, quis  gravida magna mi a libero.  Fusce vulputate eleifend sapien.  Vestibulum  purus quam, scelerisque ut, mollis sed, nonummy id, metus.  Nullam  accumsan lorem in dui.  Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.  Praesent  adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy  metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n</div>', '', 1, 1, 0, 7, '2010-08-11 06:51:12', 62, '', '2010-08-11 06:52:59', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 0, 0, 4, '', '', 0, 0, 'robots=\nauthor='),
(12, 'nhip cau trai tim 1', 'nhip-cau-trai-tim-1', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Aenean imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar, hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.  Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Etiam sit amet orci eget eros faucibus tincidunt.  Duis leo.  Sed  fringilla mauris sit amet nibh.  Donec sodales sagittis magna.  Sed  consequat, leo eget bibendum sodales, augue velit cursus nunc, quis  gravida magna mi a libero.  Fusce vulputate eleifend sapien.  Vestibulum  purus quam, scelerisque ut, mollis sed, nonummy id, metus.  Nullam  accumsan lorem in dui.  Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.  Praesent  adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy  metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n</div>', '', 1, 1, 0, 7, '2010-08-11 06:51:12', 62, '', '2010-08-11 06:52:37', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 0, 0, 3, '', '', 0, 0, 'robots=\nauthor='),
(13, 'nhip cau trai tim 3', 'nhip-cau-trai-tim-3', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Aenean imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar, hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.  Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Etiam sit amet orci eget eros faucibus tincidunt.  Duis leo.  Sed  fringilla mauris sit amet nibh.  Donec sodales sagittis magna.  Sed  consequat, leo eget bibendum sodales, augue velit cursus nunc, quis  gravida magna mi a libero.  Fusce vulputate eleifend sapien.  Vestibulum  purus quam, scelerisque ut, mollis sed, nonummy id, metus.  Nullam  accumsan lorem in dui.  Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.  Praesent  adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy  metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Lorem   ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo   ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et   magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,   ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat   massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,   vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">In  enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam   dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.    Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.    Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.    Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.    Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Aenean  imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper  ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus  eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing  sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar,  hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.   Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Etiam  sit amet orci eget eros faucibus tincidunt.  Duis leo.  Sed  fringilla  mauris sit amet nibh.  Donec sodales sagittis magna.  Sed  consequat,  leo eget bibendum sodales, augue velit cursus nunc, quis  gravida magna  mi a libero.  Fusce vulputate eleifend sapien.  Vestibulum  purus quam,  scelerisque ut, mollis sed, nonummy id, metus.  Nullam  accumsan lorem  in dui.  Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum  ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia  Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et  arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet  iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu,  accumsan a, consectetuer eget, posuere ut, mauris.  Praesent   adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy   metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum  volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl  sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy  id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit  risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam  imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus  non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien,  tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas  malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae  tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus  velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et  ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor  congue, elit erat euismod orci, ac</p>\r\n</div>\r\n</div>', '', 1, 1, 0, 7, '2010-08-11 06:51:12', 62, '', '2010-08-11 07:00:39', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 2, '', '', 0, 4, 'robots=\nauthor=');
INSERT INTO `jos_content` (`id`, `title`, `alias`, `title_alias`, `introtext`, `fulltext`, `state`, `sectionid`, `mask`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `parentid`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`) VALUES
(14, 'nhip cau trai tim 4', 'nhip-cau-trai-tim-4', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Aenean imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar, hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.  Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Etiam sit amet orci eget eros faucibus tincidunt.  Duis leo.  Sed  fringilla mauris sit amet nibh.  Donec sodales sagittis magna.  Sed  consequat, leo eget bibendum sodales, augue velit cursus nunc, quis  gravida magna mi a libero.  Fusce vulputate eleifend sapien.  Vestibulum  purus quam, scelerisque ut, mollis sed, nonummy id, metus.  Nullam  accumsan lorem in dui.  Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.  Praesent  adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy  metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n</div>', '', 1, 1, 0, 7, '2010-08-11 06:51:12', 62, '', '2010-08-11 06:53:32', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 0, 0, 1, '', '', 0, 0, 'robots=\nauthor='),
(15, 'Lưu niệm 8', 'luu-niem-8', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: justify;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: justify;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Người gửi : <span class="email">dummy text </span>- email: <span class="email">dummy@dummy.com</span></p>\r\n</div>', '', 1, 6, 0, 10, '2010-08-11 06:51:12', 62, '', '2010-08-12 08:07:31', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 4, 0, 8, '', '', 0, 0, 'robots=\nauthor='),
(23, 'Danh sách nhà tài trợ quý 4  - 2010', 'danh-sach-tai-tro-quy4-2009', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Aenean imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar, hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.  Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Etiam sit amet orci eget eros faucibus tincidunt.  Duis leo.  Sed  fringilla mauris sit amet nibh.  Donec sodales sagittis magna.  Sed  consequat, leo eget bibendum sodales, augue velit cursus nunc, quis  gravida magna mi a libero.  Fusce vulputate eleifend sapien.  Vestibulum  purus quam, scelerisque ut, mollis sed, nonummy id, metus.  Nullam  accumsan lorem in dui.  Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.  Praesent  adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy  metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n</div>', '', 1, 6, 0, 11, '2010-08-11 06:51:12', 62, '', '2010-08-24 07:31:51', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 2, 0, 16, '', '', 0, 0, 'robots=\nauthor='),
(16, 'Lưu niệm 7', 'luu-niem-7', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: justify;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: justify;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Người gửi : <span class="email">dummy text</span> - email: <span class="email">dummy@dummy.com</span></p>\r\n</div>', '', 1, 6, 0, 10, '2010-08-11 06:51:12', 62, '', '2010-08-12 08:07:36', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 5, 0, 7, '', '', 0, 2, 'robots=\nauthor='),
(24, 'Danh sách nhà tài trợ quý 3 - 2010', 'danh-sach-tai-tro-quy3-2010', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Aenean imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar, hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.  Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Etiam sit amet orci eget eros faucibus tincidunt.  Duis leo.  Sed  fringilla mauris sit amet nibh.  Donec sodales sagittis magna.  Sed  consequat, leo eget bibendum sodales, augue velit cursus nunc, quis  gravida magna mi a libero.  Fusce vulputate eleifend sapien.  Vestibulum  purus quam, scelerisque ut, mollis sed, nonummy id, metus.  Nullam  accumsan lorem in dui.  Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.  Praesent  adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy  metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Lorem   ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo   ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et   magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,   ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat   massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,   vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">In  enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam   dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.    Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.    Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.    Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.    Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Aenean  imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper  ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus  eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing  sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar,  hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.   Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Etiam  sit amet orci eget eros faucibus tincidunt.  Duis leo.  Sed  fringilla  mauris sit amet nibh.  Donec sodales sagittis magna.  Sed  consequat,  leo eget bibendum sodales, augue velit cursus nunc, quis  gravida magna  mi a libero.  Fusce vulputate eleifend sapien.  Vestibulum  purus quam,  scelerisque ut, mollis sed, nonummy id, metus.  Nullam  accumsan lorem  in dui.  Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum  ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia  Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et  arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet  iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu,  accumsan a, consectetuer eget, posuere ut, mauris.  Praesent   adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy   metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum  volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl  sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy  id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit  risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam  imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus  non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien,  tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas  malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae  tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus  velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et  ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor  congue, elit erat euismod orci, ac</p>\r\n</div>\r\n</div>', '', 1, 6, 0, 11, '2010-08-11 06:51:12', 62, '', '2010-08-24 07:31:37', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 2, 0, 15, '', '', 0, 2, 'robots=\nauthor='),
(17, 'Lưu niệm 6', 'luu-niem-6', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: justify;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: justify;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Người gửi :<span class="email"> dummy text</span> - email:<span class="email"> dummy@dummy.com</span></p>\r\n</div>', '', 1, 6, 0, 10, '2010-08-11 06:51:12', 62, '', '2010-08-12 08:07:14', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 4, 0, 6, '', '', 0, 0, 'robots=\nauthor='),
(18, 'Lưu niệm 5', 'luu-niem-5', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: justify;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Người gửi : <span class="email">dummy text</span> - email: <span class="email">dummy@dummy.com</span></p>\r\n</div>', '', 1, 6, 0, 10, '2010-08-11 06:51:12', 62, '', '2010-08-12 08:07:07', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 4, 0, 5, '', '', 0, 0, 'robots=\nauthor='),
(25, 'Danh sách nhà tài trợ quý 2 - 2010', 'danh-sach-tai-tro-quy2-2010', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Aenean imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar, hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.  Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Etiam sit amet orci eget eros faucibus tincidunt.  Duis leo.  Sed  fringilla mauris sit amet nibh.  Donec sodales sagittis magna.  Sed  consequat, leo eget bibendum sodales, augue velit cursus nunc, quis  gravida magna mi a libero.  Fusce vulputate eleifend sapien.  Vestibulum  purus quam, scelerisque ut, mollis sed, nonummy id, metus.  Nullam  accumsan lorem in dui.  Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.  Praesent  adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy  metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n</div>', '', 1, 6, 0, 11, '2010-08-11 06:51:12', 62, '', '2010-08-24 07:31:25', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 3, 0, 14, '', '', 0, 0, 'robots=\nauthor='),
(19, 'Lưu niệm 4', 'luu-niem-4', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: justify;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: justify;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Người gửi : <span class="email">dummy text </span>- email: <span class="email">dummy@dummy.com</span></p>\r\n</div>', '', 1, 6, 0, 10, '2010-08-11 06:51:12', 62, '', '2010-08-12 08:06:58', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 4, 0, 4, '', '', 0, 0, 'robots=\nauthor='),
(20, 'Lưu niệm 3', 'luu-niem-3', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: justify;">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.  Praesent  adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy  metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: justify;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Người gửi : <span class="email">dummy text</span> - email: <span class="email">dummy@dummy.com</span></p>\r\n</div>', '', 1, 6, 0, 10, '2010-08-11 06:51:12', 62, '', '2010-08-12 08:06:49', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 4, 0, 3, '', '', 0, 0, 'robots=\nauthor='),
(26, 'Danh sách nhà tài trợ quý 1 - 2010', 'danh-sach-tai-tro-quy1-2010', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Aenean imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar, hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.  Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Etiam sit amet orci eget eros faucibus tincidunt.  Duis leo.  Sed  fringilla mauris sit amet nibh.  Donec sodales sagittis magna.  Sed  consequat, leo eget bibendum sodales, augue velit cursus nunc, quis  gravida magna mi a libero.  Fusce vulputate eleifend sapien.  Vestibulum  purus quam, scelerisque ut, mollis sed, nonummy id, metus.  Nullam  accumsan lorem in dui.  Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.  Praesent  adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy  metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n</div>', '', 1, 6, 0, 11, '2010-08-11 06:51:12', 62, '', '2010-08-24 07:31:13', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 2, 0, 13, '', '', 0, 0, 'robots=\nauthor='),
(21, 'Lưu niệm 2', 'luu-niem-2', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: justify;">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.  Praesent  adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy  metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: justify;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Người gửi : <span class="email">dummy text</span> - email: <span class="email">dummy@dummy.com</span></p>\r\n</div>', '', 1, 6, 0, 10, '2010-08-11 06:51:12', 62, '', '2010-08-12 08:06:41', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 4, 0, 2, '', '', 0, 0, 'robots=\nauthor='),
(22, 'Lưu niệm 1', 'luu-niem-1', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: justify;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: justify;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Người gửi : <span class="email">dummy text</span> - email: <span class="email">dummy@dummy.com</span></p>\r\n</div>', '', 1, 6, 0, 10, '2010-08-11 06:51:12', 62, '', '2010-08-12 08:06:32', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 4, 0, 1, '', '', 0, 0, 'robots=\nauthor=');
INSERT INTO `jos_content` (`id`, `title`, `alias`, `title_alias`, `introtext`, `fulltext`, `state`, `sectionid`, `mask`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `parentid`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`) VALUES
(27, 'Danh sách nhà tài trợ quý 4 - 2007', 'danh-sach-tai-tro-quy4-2007', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Aenean imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar, hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.  Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Etiam sit amet orci eget eros faucibus tincidunt.  Duis leo.  Sed  fringilla mauris sit amet nibh.  Donec sodales sagittis magna.  Sed  consequat, leo eget bibendum sodales, augue velit cursus nunc, quis  gravida magna mi a libero.  Fusce vulputate eleifend sapien.  Vestibulum  purus quam, scelerisque ut, mollis sed, nonummy id, metus.  Nullam  accumsan lorem in dui.  Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.  Praesent  adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy  metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n</div>', '', 1, 6, 0, 11, '2009-11-30 06:51:12', 62, '', '2010-08-24 09:51:12', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 3, 0, 12, '', '', 0, 1, 'robots=\nauthor='),
(28, 'Danh sách nhà tài trợ quý 3 - 2007', 'danh-sach-tai-tro-quy3-2007', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Aenean imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar, hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.  Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Etiam sit amet orci eget eros faucibus tincidunt.  Duis leo.  Sed  fringilla mauris sit amet nibh.  Donec sodales sagittis magna.  Sed  consequat, leo eget bibendum sodales, augue velit cursus nunc, quis  gravida magna mi a libero.  Fusce vulputate eleifend sapien.  Vestibulum  purus quam, scelerisque ut, mollis sed, nonummy id, metus.  Nullam  accumsan lorem in dui.  Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.  Praesent  adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy  metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n</div>', '', 1, 6, 0, 11, '2009-11-19 06:51:12', 62, '', '2010-08-24 09:50:54', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 4, 0, 11, '', '', 0, 1, 'robots=\nauthor='),
(29, 'Danh sách nhà tài trợ quý 1 - 2007', 'danh-sach-nha-tai-tr-quy-i2007', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Aenean imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar, hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.  Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Etiam sit amet orci eget eros faucibus tincidunt.  Duis leo.  Sed  fringilla mauris sit amet nibh.  Donec sodales sagittis magna.  Sed  consequat, leo eget bibendum sodales, augue velit cursus nunc, quis  gravida magna mi a libero.  Fusce vulputate eleifend sapien.  Vestibulum  purus quam, scelerisque ut, mollis sed, nonummy id, metus.  Nullam  accumsan lorem in dui.  Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.  Praesent  adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy  metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n</div>', '', 1, 6, 0, 11, '2009-09-02 06:51:12', 62, '', '2010-08-24 09:50:42', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 6, 0, 10, '', '', 0, 1, 'robots=\nauthor='),
(30, 'Danh sách nhà tài trợ quý 2 - 2007', 'danh-sach-tai-tro-quy2-2007', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Aenean imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar, hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.  Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Etiam sit amet orci eget eros faucibus tincidunt.  Duis leo.  Sed  fringilla mauris sit amet nibh.  Donec sodales sagittis magna.  Sed  consequat, leo eget bibendum sodales, augue velit cursus nunc, quis  gravida magna mi a libero.  Fusce vulputate eleifend sapien.  Vestibulum  purus quam, scelerisque ut, mollis sed, nonummy id, metus.  Nullam  accumsan lorem in dui.  Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.  Praesent  adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy  metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n</div>', '', 1, 6, 0, 11, '2009-12-02 06:51:12', 62, '', '2010-08-24 09:50:25', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 5, 0, 9, '', '', 0, 1, 'robots=\nauthor='),
(38, 'Tin nhắn mới', '', '', '', 'Your name (required)', -2, 6, 0, 10, '2010-08-15 14:49:23', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 14:49:23', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(36, 'Tin nhắn mới', '', '', '', 'test', -2, 6, 0, 10, '2010-08-15 14:09:23', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 14:09:23', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(37, 'Tin nhắn mới', '', '', '', 'test', -2, 6, 0, 10, '2010-08-15 14:10:52', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 14:10:52', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(35, 'Tin nhắn mới', '', '', '', 'test', -2, 6, 0, 10, '2010-08-15 14:09:23', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 14:09:23', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(39, 'Tin nhắn mới', '', '', '', 'Your name (required)', -2, 6, 0, 10, '2010-08-15 14:49:56', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 14:49:56', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(40, 'Tin nhắn mới', '', '', '', 'Your name (required)', -2, 6, 0, 10, '2010-08-15 14:58:55', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 14:58:55', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(41, 'Tin nhắn mới', '', '', '', 'Your name (required)', -2, 6, 0, 10, '2010-08-15 14:58:59', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 14:58:59', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(42, 'Tin nhắn mới', '', '', '', '', -2, 6, 0, 10, '2010-08-15 15:17:51', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 15:17:51', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(43, 'Tin nhắn mới', '', '', '', '', -2, 6, 0, 10, '2010-08-15 15:19:34', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 15:19:34', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(44, 'Tin nhắn mới', '', '', '', '', -2, 6, 0, 10, '2010-08-15 15:34:40', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 15:34:40', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(45, 'Tin nhắn mới', '', '', '', '', -2, 6, 0, 10, '2010-08-15 15:35:21', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 15:35:21', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(46, 'Tin nhắn mới', '', '', '', '', -2, 6, 0, 10, '2010-08-15 15:36:56', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 15:36:56', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(47, 'Tin nhắn mới', '', '', '', '', -2, 6, 0, 10, '2010-08-15 15:39:05', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 15:39:05', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(48, 'Tin nhắn mới', '', '', '', '', -2, 6, 0, 10, '2010-08-15 15:46:36', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 15:46:36', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(49, 'Tin nhắn mới', '', '', '', '', -2, 6, 0, 10, '2010-08-15 15:48:14', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 15:48:14', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(50, 'Tin nhắn mới', '', '', '', '', -2, 6, 0, 10, '2010-08-15 15:50:04', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 15:50:04', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(51, 'Tin nhắn mới', '', '', '', '', -2, 6, 0, 10, '2010-08-15 15:50:54', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 15:50:54', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(52, 'Tin nhắn mới', '', '', '', '', -2, 6, 0, 10, '2010-08-15 15:53:23', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 15:53:23', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(53, 'Tin nhắn mới', '', '', '', '', -2, 6, 0, 10, '2010-08-15 15:54:34', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 15:54:34', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(54, 'Tin nhắn mới', '', '', '', '', -2, 6, 0, 10, '2010-08-15 16:02:34', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 16:02:34', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(55, 'Tin nhắn mới', '', '', '', '', -2, 6, 0, 10, '2010-08-15 16:08:06', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 16:08:06', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(56, 'Tin nhắn mới', '', '', '<br/><span class="email">Sender: </span><span class="email">Email: </span>', '', -2, 6, 0, 10, '2010-08-15 16:18:17', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 16:18:17', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(57, 'Tin nhắn mới', '', '', '<br/>Người gửi: <span class="email"></span> - Email: <span class="email"></span>', '', -2, 6, 0, 10, '2010-08-15 16:20:58', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 16:20:58', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(58, 'Tin nhắn mới', '', '', 'this is a test<br/>Người gửi: <span class="email">test</span> - Email: <span class="email">test@vxg.vn</span>', '', -2, 6, 0, 10, '2010-08-15 16:24:03', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 16:24:03', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(59, 'Tin nhắn mới', '', '', '<br/>Người gửi: <span class="email"></span> - Email: <span class="email"></span>', '', -2, 6, 0, 10, '2010-08-15 16:28:47', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 16:28:47', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(60, 'Tin nhắn mới', '', '', '<br/>Người gửi: <span class="email"></span> - Email: <span class="email"></span>', '', -2, 6, 0, 10, '2010-08-15 16:31:52', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 16:31:52', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(61, 'Tin nhắn mới', '', '', '<br/>Người gửi: <span class="email"></span> - Email: <span class="email"></span>', '', -2, 6, 0, 10, '2010-08-15 16:33:02', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 16:33:02', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(62, 'Tin nhắn mới', '', '', 'test dsfsdf<br/>Người gửi: <span class="email"></span> - Email: <span class="email"></span>', '', -2, 6, 0, 10, '2010-08-15 16:35:26', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 16:35:26', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(63, 'Tin nhắn mới', '', '', 'this is ridiculous, i have to use get method for ajax ?<br/>Người gửi: <span class="email">thtinh</span> - Email: <span class="email">thtinh@vxg.vn</span>', '', 1, 6, 0, 10, '2010-08-15 16:37:36', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-15 16:37:36', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(64, 'Tin nhắn mới', '', '', '123<br/>Người gửi: <span class="email">thtinh</span> - Email: <span class="email">thtinh@vxg.vn</span>', '', -2, 6, 0, 10, '2010-08-16 04:59:00', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-16 04:59:00', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(65, 'Tin nhắn mới', '', '', 'day la test duoc gui tu` IE<br/>Người gửi: <span class="email">thtinh</span> - Email: <span class="email">thtinh@yahoo.com</span>', '', 1, 6, 0, 10, '2010-08-16 06:09:01', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-16 06:09:01', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(66, 'Tin nhắn mới', '', '', 'wtf omg stfu<br/>Người gửi: <span class="email">thtinh</span> - Email: <span class="email">thtinh@abc.com</span>', '', -2, 6, 0, 10, '2010-08-16 06:17:22', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-16 06:17:22', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(67, 'Tin nhắn mới', '', '', 'falskfsdf<br/>Người gửi: <span class="email">thtinh</span> - Email: <span class="email">thtinh@vxg.vn</span>', '', -2, 6, 0, 10, '2010-08-16 06:19:06', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-16 06:19:06', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(68, 'Tin nhắn mới', '', '', 'test<br/>Người gửi: <span class="email">Uyen</span> - Email: <span class="email">uyen@vxg.vn</span>', '', -2, 6, 0, 10, '2010-08-16 06:29:42', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-16 06:29:42', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(69, 'Tin nhắn mới', '', '', 'asdlkfajsdlfkajsdlkfajs<br/>Người gửi: <span class="email">thtinh</span> - Email: <span class="email">thtinh@vxg.vn</span>', '', -2, 6, 0, 10, '2010-08-16 06:48:44', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-16 06:48:44', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(70, 'Tin nhắn mới', '', '', '123 asdfasdf<br/>Người gửi: <span class="email">thtinh</span> - Email: <span class="email">thtinh@vxg.vn</span>', '', -2, 6, 0, 10, '2010-08-16 06:49:22', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-16 06:49:22', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(71, 'Tin nhắn mới', '', '', 'http://arsenal-2/hb/index.php?option=com_content&view=category&layout=blog&id=10&Itemid=13<br/>Người gửi: <span class="email">thtinh</span> - Email: <span class="email">thinh@vxg.nv</span>', '', -2, 6, 0, 10, '2010-08-16 06:51:09', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-16 06:51:09', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(72, 'Tin nhắn mới', '', '', '123asdasdfasdfs<br/>Người gửi: <span class="email">thtinh</span> - Email: <span class="email">thtinh@vxg.vn</span>', '', -2, 6, 0, 10, '2010-08-16 06:55:57', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-16 06:55:57', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(73, 'Tin nhắn mới', '', '', 'tesfasdfasdfasdf<br/>Người gửi: <span class="email">thtinh</span> - Email: <span class="email">thtinh@vxg.vn</span>', '', -2, 6, 0, 10, '2010-08-16 06:56:47', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-16 06:56:47', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(74, 'Tin nhắn mới', '', '', 'eqlkwj''asldjkf\na SJ\nSLDF\nAKSDFASDFASDFASDFA<br/>Người gửi: <span class="email">thtinh</span> - Email: <span class="email">thtinh@vxg.vn</span>', '', -2, 6, 0, 10, '2010-08-16 07:00:10', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-16 07:00:10', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(75, 'Tin nhắn mới', '', '', 'adfsdfsafsd<br/>Người gửi: <span class="email">stsadf</span> - Email: <span class="email">asdfasdf@vxcvx.com</span>', '', -2, 6, 0, 10, '2010-08-16 07:00:46', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-16 07:00:46', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(76, 'Tin nhắn mới', '', '', 'this is a test<br/>Người gửi: <span class="email">thtinh</span> - Email: <span class="email">thtinh@vxg.vn</span>', '', 0, 6, 0, 10, '2010-08-16 14:18:47', 63, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-16 14:18:47', '0000-00-00 00:00:00', '', '', '', 1, 0, 0, '', '', 0, 0, ''),
(77, 'Danh sách nhà tài trợ quý 2 - 2009', 'danh-sach-tai-tro-quy2-2009', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Aenean imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar, hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.  Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Etiam sit amet orci eget eros faucibus tincidunt.  Duis leo.  Sed  fringilla mauris sit amet nibh.  Donec sodales sagittis magna.  Sed  consequat, leo eget bibendum sodales, augue velit cursus nunc, quis  gravida magna mi a libero.  Fusce vulputate eleifend sapien.  Vestibulum  purus quam, scelerisque ut, mollis sed, nonummy id, metus.  Nullam  accumsan lorem in dui.  Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.  Praesent  adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy  metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n</div>', '', 1, 6, 0, 11, '2009-12-02 06:51:12', 62, '', '2009-09-19 07:30:07', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 0, 0, 8, '', '', 0, 1, 'robots=\nauthor='),
(78, 'Danh sách nhà tài trợ quý 1 - 2009', 'danh-sach-nha-tai-tr-quy-i2009', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Aenean imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar, hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.  Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Etiam sit amet orci eget eros faucibus tincidunt.  Duis leo.  Sed  fringilla mauris sit amet nibh.  Donec sodales sagittis magna.  Sed  consequat, leo eget bibendum sodales, augue velit cursus nunc, quis  gravida magna mi a libero.  Fusce vulputate eleifend sapien.  Vestibulum  purus quam, scelerisque ut, mollis sed, nonummy id, metus.  Nullam  accumsan lorem in dui.  Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.  Praesent  adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy  metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n</div>', '', 1, 6, 0, 11, '2009-09-02 06:51:12', 62, '', '2009-11-26 07:29:42', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 0, 0, 7, '', '', 0, 0, 'robots=\nauthor='),
(79, 'Danh sách nhà tài trợ quý 3 - 2009', 'danh-sach-tai-tro-quy3-2009', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Aenean imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar, hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.  Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Etiam sit amet orci eget eros faucibus tincidunt.  Duis leo.  Sed  fringilla mauris sit amet nibh.  Donec sodales sagittis magna.  Sed  consequat, leo eget bibendum sodales, augue velit cursus nunc, quis  gravida magna mi a libero.  Fusce vulputate eleifend sapien.  Vestibulum  purus quam, scelerisque ut, mollis sed, nonummy id, metus.  Nullam  accumsan lorem in dui.  Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.  Praesent  adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy  metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n</div>', '', 1, 6, 0, 11, '2009-11-19 06:51:12', 62, '', '2009-10-13 07:30:48', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 0, 0, 6, '', '', 0, 1, 'robots=\nauthor=');
INSERT INTO `jos_content` (`id`, `title`, `alias`, `title_alias`, `introtext`, `fulltext`, `state`, `sectionid`, `mask`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `parentid`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`) VALUES
(80, 'Danh sách nhà tài trợ quý 4 - 2009', 'danh-sach-tai-tro-quy4-2009', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Aenean imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar, hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.  Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Etiam sit amet orci eget eros faucibus tincidunt.  Duis leo.  Sed  fringilla mauris sit amet nibh.  Donec sodales sagittis magna.  Sed  consequat, leo eget bibendum sodales, augue velit cursus nunc, quis  gravida magna mi a libero.  Fusce vulputate eleifend sapien.  Vestibulum  purus quam, scelerisque ut, mollis sed, nonummy id, metus.  Nullam  accumsan lorem in dui.  Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.  Praesent  adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy  metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n</div>', '', 1, 6, 0, 11, '2009-11-30 06:51:12', 62, '', '2010-08-24 07:31:00', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 0, 0, 5, '', '', 0, 1, 'robots=\nauthor='),
(81, 'Danh sách nhà tài trợ quý 1 - 2008', 'danh-sach-tai-tro-quy1-2008', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Aenean imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar, hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.  Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Etiam sit amet orci eget eros faucibus tincidunt.  Duis leo.  Sed  fringilla mauris sit amet nibh.  Donec sodales sagittis magna.  Sed  consequat, leo eget bibendum sodales, augue velit cursus nunc, quis  gravida magna mi a libero.  Fusce vulputate eleifend sapien.  Vestibulum  purus quam, scelerisque ut, mollis sed, nonummy id, metus.  Nullam  accumsan lorem in dui.  Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.  Praesent  adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy  metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n</div>', '', 1, 6, 0, 11, '2010-08-11 06:51:12', 62, '', '2010-08-24 09:49:41', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 4, '', '', 0, 0, 'robots=\nauthor='),
(82, 'Danh sách nhà tài trợ quý 2 - 2008', 'danh-sach-tai-tro-quy2-2008', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Aenean imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar, hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.  Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Etiam sit amet orci eget eros faucibus tincidunt.  Duis leo.  Sed  fringilla mauris sit amet nibh.  Donec sodales sagittis magna.  Sed  consequat, leo eget bibendum sodales, augue velit cursus nunc, quis  gravida magna mi a libero.  Fusce vulputate eleifend sapien.  Vestibulum  purus quam, scelerisque ut, mollis sed, nonummy id, metus.  Nullam  accumsan lorem in dui.  Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.  Praesent  adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy  metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n</div>', '', 1, 6, 0, 11, '2010-08-11 06:51:12', 62, '', '2010-08-24 09:49:24', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 3, '', '', 0, 0, 'robots=\nauthor='),
(83, 'Danh sách nhà tài trợ quý 3 - 2008', 'danh-sach-tai-tro-quy3-2008', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Aenean imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar, hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.  Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Etiam sit amet orci eget eros faucibus tincidunt.  Duis leo.  Sed  fringilla mauris sit amet nibh.  Donec sodales sagittis magna.  Sed  consequat, leo eget bibendum sodales, augue velit cursus nunc, quis  gravida magna mi a libero.  Fusce vulputate eleifend sapien.  Vestibulum  purus quam, scelerisque ut, mollis sed, nonummy id, metus.  Nullam  accumsan lorem in dui.  Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.  Praesent  adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy  metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Lorem   ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo   ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et   magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,   ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat   massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,   vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">In  enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam   dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.    Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.    Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.    Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.    Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Aenean  imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper  ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus  eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing  sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar,  hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.   Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Etiam  sit amet orci eget eros faucibus tincidunt.  Duis leo.  Sed  fringilla  mauris sit amet nibh.  Donec sodales sagittis magna.  Sed  consequat,  leo eget bibendum sodales, augue velit cursus nunc, quis  gravida magna  mi a libero.  Fusce vulputate eleifend sapien.  Vestibulum  purus quam,  scelerisque ut, mollis sed, nonummy id, metus.  Nullam  accumsan lorem  in dui.  Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum  ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia  Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et  arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet  iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu,  accumsan a, consectetuer eget, posuere ut, mauris.  Praesent   adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy   metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum  volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl  sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy  id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit  risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam  imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus  non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien,  tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas  malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae  tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus  velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et  ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor  congue, elit erat euismod orci, ac</p>\r\n</div>\r\n</div>', '', 1, 6, 0, 11, '2010-08-11 06:51:12', 62, '', '2010-08-24 09:49:11', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 2, '', '', 0, 0, 'robots=\nauthor='),
(84, 'Danh sách nhà tài trợ quý 4  - 2008', 'danh-sach-tai-tro-quy4-2008', '', '<div id="idTextPanel">\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.  Nullam  dictum felis eu pede mollis pretium.  Integer tincidunt.  Cras dapibus.   Vivamus elementum semper nisi.  Aenean vulputate eleifend tellus.   Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.   Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Aenean imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar, hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.  Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Etiam sit amet orci eget eros faucibus tincidunt.  Duis leo.  Sed  fringilla mauris sit amet nibh.  Donec sodales sagittis magna.  Sed  consequat, leo eget bibendum sodales, augue velit cursus nunc, quis  gravida magna mi a libero.  Fusce vulputate eleifend sapien.  Vestibulum  purus quam, scelerisque ut, mollis sed, nonummy id, metus.  Nullam  accumsan lorem in dui.  Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices  posuere cubilia Curae; In ac dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.  Praesent  adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc nonummy  metus.</p>\r\n<p style="font-family: Verdana,Geneva,sans-serif; font-style: normal; font-weight: normal; font-size: 10px; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;">Vestibulum volutpat pretium libero.  Cras id dui.  Aenean ut eros et  nisl sagittis vestibulum.  Nullam nulla eros, ultricies sit amet,  nonummy id, imperdiet feugiat, pede.  Sed lectus.  Donec mollis  hendrerit risus.  Phasellus nec sem in justo pellentesque facilisis.   Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus leo dolor,  tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.  Donec posuere vulputate arcu.   Phasellus accumsan cursus velit.  Vestibulum ante ipsum primis in  faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam,  nisi quis porttitor congue, elit erat euismod orci, ac</p>\r\n</div>', '', 1, 6, 0, 11, '2010-08-11 06:51:12', 62, '', '2010-08-24 09:48:52', 62, 0, '0000-00-00 00:00:00', '2010-08-11 06:51:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 1, '', '', 0, 0, 'robots=\nauthor='),
(85, 'Slide 1', 'slide-1', '', '<p><img src="images/stories/slideshow/slide1.jpg" border="0" alt="Hội chữ thập đỏ - Chung sức vì cộng đồng" title="Hội chữ thập đỏ - Chung sức vì cộng đồng" width="844" height="325" /></p>', '', 1, 5, 0, 13, '2010-08-26 15:29:02', 62, '', '2010-08-27 15:33:06', 62, 0, '0000-00-00 00:00:00', '2010-08-26 15:29:02', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 3, 0, 3, '', '', 0, 0, 'robots=\nauthor='),
(86, 'Slide 2', 'slide-2', '', '<p><img src="images/stories/slideshow/slide2.jpg" border="0" alt="Hội chữ thập đỏ - Chung sức vì cộng đồng" title="Hội chữ thập đỏ - Chung sức vì cộng đồng" width="767" height="273" /></p>', '', 1, 5, 0, 13, '2010-08-26 15:31:09', 62, '', '2010-08-27 15:33:30', 62, 0, '0000-00-00 00:00:00', '2010-08-26 15:31:09', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 2, 0, 2, '', '', 0, 0, 'robots=\nauthor='),
(87, 'Slide 3', 'slide-3', '', '<p><img src="images/stories/slideshow/slide3.jpg" border="0" alt="Đi bộ đồng hành - Vì nạn nhân chất độc màu da cam" title="Đi bộ đồng hành - Vì nạn nhân chất độc màu da cam" width="697" height="302" /></p>', '', 1, 5, 0, 13, '2010-08-26 15:32:10', 62, '', '2010-08-27 15:32:58', 62, 0, '0000-00-00 00:00:00', '2010-08-26 15:32:10', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 2, 0, 1, '', '', 0, 0, 'robots=\nauthor='),
(88, 'Thư viện ảnh', 'th-vin-nh', '', '<p>{loadposition photoslide}</p>\r\n<p><a class="button lightcurve lightshadow" href="#">Ảnh truyền thống</a> <a class="button lightcurve lightshadow" href="#">Ảnh sự kiện</a> <a class="button lightcurve lightshadow" href="#">Ảnh hoạt động</a></p>', '', 1, 7, 0, 12, '2010-08-26 15:46:04', 62, '', '2010-08-26 18:55:23', 62, 0, '0000-00-00 00:00:00', '2010-08-26 15:46:04', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 6, 0, 2, '', '', 0, 0, 'robots=\nauthor='),
(89, 'Video Clip', 'video-clip', '', '<p>{loadposition videoclip}</p>', '', 1, 7, 0, 12, '2010-08-26 16:37:02', 62, '', '2010-08-26 18:50:43', 62, 0, '0000-00-00 00:00:00', '2010-08-26 16:37:02', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 3, 0, 3, '', '', 0, 0, 'robots=\nauthor='),
(90, 'Giới thiệu', 'gioi-thieu', '', '<div id="idTextPanel">\r\n<p style="font-style: normal; font-weight: normal; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: justify;"><span style="font-size: small;"><span style="font-family: arial,helvetica,sans-serif;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.  In enim justo, rhoncus ut, imperdiet a, venenatis  vitae, justo.  Nullam dictum felis eu pede mollis pretium.  Integer  tincidunt.  Cras dapibus.  Vivamus elementum semper nisi.  Aenean  vulputate eleifend tellus.  Aenean leo ligula, porttitor eu, consequat  vitae, eleifend ac, enim.</span></span></p>\r\n<p style="text-align: center;"><img src="images/stories/slideshow/slide1.jpg" border="0" alt="Hình ảnh do Làng Hòa Bình cung cấp" title="Hình ảnh do Làng Hòa Bình cung cấp" style="vertical-align: middle;" /></p>\r\n<p style="font-style: normal; font-weight: normal; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: justify;"><span style="font-size: small;"><span style="font-family: arial,helvetica,sans-serif;">Praesent adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc  nonummy metus.  Vestibulum volutpat pretium libero.  Cras id dui.   Aenean ut eros et nisl sagittis vestibulum.  Nullam nulla eros,  ultricies sit amet, nonummy id, imperdiet feugiat, pede.  Sed lectus.   Donec mollis hendrerit risus.  Phasellus nec sem in justo pellentesque  facilisis.  Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus  leo dolor, tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.</span></span></p>\r\n<ul>\r\n<li class="email"><span class="textstyle1"><a class="email" href="index.php?option=com_content&amp;view=article&amp;id=94&amp;Itemid=3" title="Lịch sử thành lập">Lịch sử thành lập</a></span></li>\r\n<li class="email">Các hoạt động chính</li>\r\n<li class="email">Tổ chức</li>\r\n<li class="email">Công tác đào tạo</li>\r\n</ul>\r\n<p style="font-style: normal; font-weight: normal; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: justify;"><span style="font-size: small;"><span style="font-family: arial,helvetica,sans-serif;">Suspendisse pulvinar, augue ac venenatis condimentum, sem libero  volutpat nibh, nec pellentesque velit pede quis nunc.  Vestibulum ante  ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae;  Fusce id purus.  Ut varius tincidunt libero.  Phasellus dolor.  Maecenas  vestibulum mollis diam.  Pellentesque ut neque.  Pellenteesque habitant  morbi tristique senectus et netus et malesuada fames ac turpis egestas.  In dui magna, posuere eget, vestibulum et, tempor auctor, justo.  In ac  felis quis tortor malesuada pretium.  Pellentesque auctor neque nec  urna.  Proin sapien ipsum, porta a, auctor quis, euismod ut, mi.</span></span></p>\r\n<p style="font-style: normal; font-weight: normal; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: justify;"><span style="font-size: small;"><span style="font-family: arial,helvetica,sans-serif;">Aenean viverra rhoncus pede.  Pellentesque habitant morbi tristique  senectus et netus et malesuada fames ac turpis egestas.  Ut non enim  eleifend felis pretium feugiat.  Vivamus quis mi.  Phasellus a est.   Phasellus magna.  In hac habitasse platea dictumst.  Curabitur at lacus ac velit ornare  lobortis.  Curabitur a felis in nunc fringilla tristique.  Morbi mattis  ullamcorper velit.  Phasellus gravida semper nisi.  Nullam vel sem.   Pellentesque libero tortor, tincidunt et, tincidunt eget, semper nec,  quam.  Sed hendrerit.  Morbi ac felis.  Nunc egestas, augue at  pellentesque laoreet, felis eros vehicula leo, at malesuada velit leo  quis pede.</span></span></p>\r\n</div>', '', 1, 6, 0, 19, '2010-08-28 17:44:59', 62, '', '2010-08-28 19:54:50', 62, 0, '0000-00-00 00:00:00', '2010-08-28 17:44:59', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 7, 0, 1, '', '', 0, 32, 'robots=\nauthor='),
(91, 'Năm 2002 - 2004', 'nam-2002-2004', '', '<p style="font-style: normal; font-weight: normal; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;"><span style="font-size: small;"><span style="font-family: arial,helvetica,sans-serif;"><span class="textstyle1">2002</span></span></span></p>\r\n<p style="font-style: normal; font-weight: normal; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: justify;"><span style="font-size: small;"><span style="font-family: arial,helvetica,sans-serif;">Lorem  ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo  ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et  magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,  ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat  massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,  vulputate eget, arcu.  In enim justo, rhoncus ut, imperdiet a, venenatis  vitae, justo.  Nullam dictum felis eu pede mollis pretium.  Integer  tincidunt.  Cras dapibus.  Vivamus elementum semper nisi.  Aenean  vulputate eleifend tellus.  Aenean leo ligula, porttitor eu, consequat  vitae, eleifend ac, enim.</span></span></p>\r\n<p style="font-style: normal; font-weight: normal; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;"><span style="font-size: small;"><span style="font-family: arial,helvetica,sans-serif;"><span class="textstyle1">2003</span></span></span></p>\r\n<p style="font-style: normal; font-weight: normal; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: justify;"><span style="font-size: small;"><span style="font-family: arial,helvetica,sans-serif;">Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus viverra nulla ut metus varius laoreet.  Quisque rutrum.   Aenean imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar, hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.  Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.  Etiam sit amet orci eget eros faucibus  tincidunt.  Duis leo.  Sed fringilla mauris sit amet nibh.</span></span></p>\r\n<p class="textstyle1" style="font-style: normal; font-weight: normal; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: justify;"><span style="font-size: small;"><span style="font-family: arial,helvetica,sans-serif;">2004</span></span></p>\r\n<p style="font-style: normal; font-weight: normal; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: justify;"><span style="font-size: small;"><span style="font-family: arial,helvetica,sans-serif;">Donec sodales sagittis magna.  Sed consequat, leo eget bibendum  sodales, augue velit cursus nunc, quis gravida magna mi a libero.  Fusce  vulputate eleifend sapien.  Vestibulum purus quam, scelerisque ut,  mollis sed, nonummy id, metus.  Nullam accumsan lorem in dui.  Cras  ultricies mi eu turpis hendrerit fringilla.  Vestibulum ante ipsum  primis in faucibus orci luctus et ultrices posuere cubilia Curae; In ac  dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.  Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.</span></span></p>', '', 1, 6, 0, 15, '2010-08-28 18:33:49', 62, '', '2010-08-28 18:51:00', 62, 0, '0000-00-00 00:00:00', '2010-08-28 18:33:49', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 2, 0, 1, '', '', 0, 0, 'robots=\nauthor='),
(92, 'Năm 2005 - 2007', 'nam-2005-2007', '', '<p style="font-style: normal; font-weight: normal; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;"><span style="font-size: small;"><span style="font-family: arial,helvetica,sans-serif;"><span class="textstyle1">2005</span></span></span></p>\r\n<p style="font-style: normal; font-weight: normal; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;"><span style="font-size: small;"><span style="font-family: arial,helvetica,sans-serif;">Lorem   ipsum dolor sit amet, consectetuer adipiscing elit.  Aenean commodo   ligula eget dolor.  Aenean massa.  Cum sociis natoque penatibus et   magnis dis parturient montes, nascetur ridiculus mus.  Donec quam felis,   ultricies nec, pellentesque eu, pretium quis, sem.  Nulla consequat   massa quis enim.  Donec pede justo, fringilla vel, aliquet nec,   vulputate eget, arcu.  In enim justo, rhoncus ut, imperdiet a, venenatis   vitae, justo.  Nullam dictum felis eu pede mollis pretium.  Integer   tincidunt.  Cras dapibus.  Vivamus elementum semper nisi.  Aenean   vulputate eleifend tellus.  Aenean leo ligula, porttitor eu, consequat   vitae, eleifend ac, enim.</span></span></p>\r\n<p class="textstyle1" style="font-style: normal; font-weight: normal; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;"><span style="font-size: small;"><span style="font-family: arial,helvetica,sans-serif;">2006</span></span></p>\r\n<p style="font-style: normal; font-weight: normal; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;"><span style="font-size: small;"><span style="font-family: arial,helvetica,sans-serif;">Aliquam  lorem ante, dapibus in, viverra quis, feugiat a, tellus.   Phasellus  viverra nulla ut metus varius laoreet.  Quisque rutrum.   Aenean  imperdiet.  Etiam ultricies nisi vel augue.  Curabitur  ullamcorper  ultricies nisi.  Nam eget dui.  Etiam rhoncus.  Maecenas tempus, tellus  eget condimentum rhoncus, sem  quam semper libero, sit amet adipiscing  sem neque sed ipsum.  Nam quam  nunc, blandit vel, luctus pulvinar,  hendrerit id, lorem.  Maecenas nec  odio et ante tincidunt tempus.   Donec vitae sapien ut libero venenatis  faucibus.  Nullam quis ante.   Etiam sit amet orci eget eros faucibus  tincidunt.  Duis leo.  Sed  fringilla mauris sit amet nibh.</span></span></p>\r\n<p class="textstyle1" style="font-style: normal; font-weight: normal; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;"><span style="font-size: small;"><span style="font-family: arial,helvetica,sans-serif;">2007</span></span></p>\r\n<p style="font-style: normal; font-weight: normal; letter-spacing: normal; line-height: normal; text-transform: none; text-decoration: none; text-align: left;"><span style="font-size: small;"><span style="font-family: arial,helvetica,sans-serif;">Donec  sodales sagittis magna.  Sed consequat, leo eget bibendum  sodales,  augue velit cursus nunc, quis gravida magna mi a libero.  Fusce   vulputate eleifend sapien.  Vestibulum purus quam, scelerisque ut,   mollis sed, nonummy id, metus.  Nullam accumsan lorem in dui.  Cras   ultricies mi eu turpis hendrerit fringilla.  Vestibulum ante ipsum   primis in faucibus orci luctus et ultrices posuere cubilia Curae; In ac   dui quis mi consectetuer lacinia.  Nam pretium turpis et arcu.  Duis  arcu tortor, suscipit eget, imperdiet  nec, imperdiet iaculis, ipsum.   Sed aliquam ultrices mauris.  Integer  ante arcu, accumsan a,  consectetuer eget, posuere ut, mauris.</span></span></p>', '', 1, 6, 0, 15, '2010-08-28 18:39:11', 62, '', '2010-08-28 18:51:21', 62, 0, '0000-00-00 00:00:00', '2010-08-28 18:39:11', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 2, 0, 2, '', '', 0, 0, 'robots=\nauthor='),
(93, 'intro', 'intro', '', '<p>Praesent adipiscing.  Phasellus ullamcorper ipsum rutrum nunc.  Nunc  nonummy metus.  Vestibulum volutpat pretium libero.  Cras id dui.   Aenean ut eros et nisl sagittis vestibulum.  Nullam nulla eros,  ultricies sit amet, nonummy id, imperdiet feugiat, pede.  Sed lectus.   Donec mollis hendrerit risus.  Phasellus nec sem in justo pellentesque  facilisis.  Etiam imperdiet imperdiet orci.  Nunc nec neque.  Phasellus  leo dolor, tempus non, auctor et, hendrerit quis, nisi.  Curabitur ligula sapien, tincidunt non, euismod vitae, posuere  imperdiet, leo.  Maecenas malesuada.  Praesent congue erat at massa.   Sed cursus turpis vitae tortor.</p>', '', -2, 6, 0, 15, '2010-08-28 18:40:12', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2010-08-28 18:40:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 0, '', '', 0, 0, 'robots=\nauthor='),
(94, 'Lịch sử thành lập', 'lich-su-thanh-lap', '', '<p>Aenean viverra rhoncus pede.  Pellentesque habitant morbi tristique   senectus et netus et malesuada fames ac turpis egestas.  Ut non enim   eleifend felis pretium feugiat.  Vivamus quis mi.  Phasellus a est.    Phasellus magna.  In hac habitasse platea dictumst.  Curabitur at lacus  ac velit ornare  lobortis.  Curabitur a felis in nunc fringilla  tristique.  Morbi mattis  ullamcorper velit.  Phasellus gravida semper  nisi.  Nullam vel sem.   Pellentesque libero tortor, tincidunt et,  tincidunt eget, semper nec,  quam.  Sed hendrerit.  Morbi ac felis.   Nunc egestas, augue at  pellentesque laoreet, felis eros vehicula leo,  at malesuada velit leo  quis pede</p>\r\n<p>{loadposition history}</p>', '', 1, 7, 0, 12, '2010-08-28 18:44:37', 62, '', '2010-08-28 19:47:55', 62, 0, '0000-00-00 00:00:00', '2010-08-28 18:44:37', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 2, 0, 1, '', '', 0, 33, 'robots=\nauthor='),
(95, 'Lời giới thiệu', 'loi-gioi-thieu', '', '<p>Aenean viverra rhoncus pede.  Pellentesque habitant morbi tristique  senectus et netus et malesuada fames ac turpis egestas.  Ut non enim  eleifend felis pretium feugiat.  Vivamus quis mi.  Phasellus a est.   Phasellus magna.  In hac habitasse platea dictumst.  Curabitur at lacus ac velit ornare  lobortis.  Curabitur a felis in nunc fringilla tristique.  Morbi mattis  ullamcorper velit.  Phasellus gravida semper nisi.  Nullam vel sem.   Pellentesque libero tortor, tincidunt et, tincidunt eget, semper nec,  quam.  Sed hendrerit.  Morbi ac felis.  Nunc egestas, augue at  pellentesque laoreet, felis eros vehicula leo, at malesuada velit leo  quis pede</p>', '', -2, 6, 0, 15, '2010-08-28 19:32:00', 62, '', '2010-08-28 19:43:32', 62, 0, '0000-00-00 00:00:00', '2010-08-28 19:32:00', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 4, 0, 0, '', '', 0, 6, 'robots=\nauthor=');

-- --------------------------------------------------------

--
-- Table structure for table `jos_content_frontpage`
--

CREATE TABLE IF NOT EXISTS `jos_content_frontpage` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`content_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_content_frontpage`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_content_rating`
--

CREATE TABLE IF NOT EXISTS `jos_content_rating` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `rating_sum` int(11) unsigned NOT NULL DEFAULT '0',
  `rating_count` int(11) unsigned NOT NULL DEFAULT '0',
  `lastip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`content_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_content_rating`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_core_acl_aro`
--

CREATE TABLE IF NOT EXISTS `jos_core_acl_aro` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_value` varchar(240) NOT NULL DEFAULT '0',
  `value` varchar(240) NOT NULL DEFAULT '',
  `order_value` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `hidden` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `jos_section_value_value_aro` (`section_value`(100),`value`(100)),
  KEY `jos_gacl_hidden_aro` (`hidden`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `jos_core_acl_aro`
--

INSERT INTO `jos_core_acl_aro` (`id`, `section_value`, `value`, `order_value`, `name`, `hidden`) VALUES
(10, 'users', '62', 0, 'Administrator', 0),
(11, 'users', '63', 0, 'hoabinh', 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_core_acl_aro_groups`
--

CREATE TABLE IF NOT EXISTS `jos_core_acl_aro_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `jos_gacl_parent_id_aro_groups` (`parent_id`),
  KEY `jos_gacl_lft_rgt_aro_groups` (`lft`,`rgt`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `jos_core_acl_aro_groups`
--

INSERT INTO `jos_core_acl_aro_groups` (`id`, `parent_id`, `name`, `lft`, `rgt`, `value`) VALUES
(17, 0, 'ROOT', 1, 22, 'ROOT'),
(28, 17, 'USERS', 2, 21, 'USERS'),
(29, 28, 'Public Frontend', 3, 12, 'Public Frontend'),
(18, 29, 'Registered', 4, 11, 'Registered'),
(19, 18, 'Author', 5, 10, 'Author'),
(20, 19, 'Editor', 6, 9, 'Editor'),
(21, 20, 'Publisher', 7, 8, 'Publisher'),
(30, 28, 'Public Backend', 13, 20, 'Public Backend'),
(23, 30, 'Manager', 14, 19, 'Manager'),
(24, 23, 'Administrator', 15, 18, 'Administrator'),
(25, 24, 'Super Administrator', 16, 17, 'Super Administrator');

-- --------------------------------------------------------

--
-- Table structure for table `jos_core_acl_aro_map`
--

CREATE TABLE IF NOT EXISTS `jos_core_acl_aro_map` (
  `acl_id` int(11) NOT NULL DEFAULT '0',
  `section_value` varchar(230) NOT NULL DEFAULT '0',
  `value` varchar(100) NOT NULL,
  PRIMARY KEY (`acl_id`,`section_value`,`value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_core_acl_aro_map`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_core_acl_aro_sections`
--

CREATE TABLE IF NOT EXISTS `jos_core_acl_aro_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(230) NOT NULL DEFAULT '',
  `order_value` int(11) NOT NULL DEFAULT '0',
  `name` varchar(230) NOT NULL DEFAULT '',
  `hidden` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `jos_gacl_value_aro_sections` (`value`),
  KEY `jos_gacl_hidden_aro_sections` (`hidden`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `jos_core_acl_aro_sections`
--

INSERT INTO `jos_core_acl_aro_sections` (`id`, `value`, `order_value`, `name`, `hidden`) VALUES
(10, 'users', 1, 'Users', 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_core_acl_groups_aro_map`
--

CREATE TABLE IF NOT EXISTS `jos_core_acl_groups_aro_map` (
  `group_id` int(11) NOT NULL DEFAULT '0',
  `section_value` varchar(240) NOT NULL DEFAULT '',
  `aro_id` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `group_id_aro_id_groups_aro_map` (`group_id`,`section_value`,`aro_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_core_acl_groups_aro_map`
--

INSERT INTO `jos_core_acl_groups_aro_map` (`group_id`, `section_value`, `aro_id`) VALUES
(24, '', 11),
(25, '', 10);

-- --------------------------------------------------------

--
-- Table structure for table `jos_core_log_items`
--

CREATE TABLE IF NOT EXISTS `jos_core_log_items` (
  `time_stamp` date NOT NULL DEFAULT '0000-00-00',
  `item_table` varchar(50) NOT NULL DEFAULT '',
  `item_id` int(11) unsigned NOT NULL DEFAULT '0',
  `hits` int(11) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_core_log_items`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_core_log_searches`
--

CREATE TABLE IF NOT EXISTS `jos_core_log_searches` (
  `search_term` varchar(128) NOT NULL DEFAULT '',
  `hits` int(11) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_core_log_searches`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_custom_properties`
--

CREATE TABLE IF NOT EXISTS `jos_custom_properties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_table` varchar(100) DEFAULT 'content',
  `content_id` int(11) NOT NULL DEFAULT '0',
  `field_id` int(11) NOT NULL DEFAULT '0',
  `value_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `t_c_f_v` (`ref_table`,`content_id`,`field_id`,`value_id`),
  KEY `content_id` (`content_id`),
  KEY `cp_field_id` (`field_id`),
  KEY `cp_value_id` (`value_id`),
  KEY `ref_table` (`ref_table`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_custom_properties`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_custom_properties_fields`
--

CREATE TABLE IF NOT EXISTS `jos_custom_properties_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(50) NOT NULL,
  `label` varchar(255) NOT NULL,
  `field_type` char(50) NOT NULL,
  `modules` varchar(255) NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `access` int(11) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `state` (`published`),
  KEY `access` (`access`),
  KEY `checked_out` (`checked_out`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `jos_custom_properties_fields`
--

INSERT INTO `jos_custom_properties_fields` (`id`, `name`, `label`, `field_type`, `modules`, `published`, `access`, `ordering`, `checked_out`) VALUES
(1, 'illness', 'Loại dị tật', 'select', '40', 1, 0, 1, 0),
(2, 'year', 'Năm sinh', 'select', '40', 1, 0, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_custom_properties_values`
--

CREATE TABLE IF NOT EXISTS `jos_custom_properties_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_id` int(11) NOT NULL DEFAULT '0',
  `name` char(50) NOT NULL,
  `label` varchar(255) NOT NULL,
  `priority` tinyint(4) NOT NULL DEFAULT '0',
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `field_id` (`field_id`),
  KEY `name` (`name`),
  KEY `priority` (`priority`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `jos_custom_properties_values`
--

INSERT INTO `jos_custom_properties_values` (`id`, `field_id`, `name`, `label`, `priority`, `default`, `ordering`) VALUES
(1, 1, 'dummy_name_1', 'dummy dị tật 1', 0, 0, 1),
(2, 1, 'dummy_name_2', 'dummy dị tật 2', 0, 0, 2),
(3, 1, 'dummy_name_3', 'dummy dị tật 3', 0, 0, 3),
(4, 1, 'dummy_name_4', 'dummy dị tật 4', 0, 0, 4),
(5, 2, '1990', '1990', 0, 0, 1),
(6, 2, '1991', '1991', 0, 0, 2),
(7, 2, '1992', '1992', 0, 0, 3),
(8, 2, '1993', '1993', 0, 0, 4);

-- --------------------------------------------------------

--
-- Table structure for table `jos_groups`
--

CREATE TABLE IF NOT EXISTS `jos_groups` (
  `id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_groups`
--

INSERT INTO `jos_groups` (`id`, `name`) VALUES
(0, 'Public'),
(1, 'Registered'),
(2, 'Special');

-- --------------------------------------------------------

--
-- Table structure for table `jos_jacomment_configs`
--

CREATE TABLE IF NOT EXISTS `jos_jacomment_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group` varchar(100) DEFAULT NULL,
  `data` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `jos_jacomment_configs`
--

INSERT INTO `jos_jacomment_configs` (`id`, `group`, `data`) VALUES
(22, 'general', 'display_message=\nis_notify_admin=1\nis_notify_author=1\nis_enabled_email=1\nccemail=\naccess=0\nis_comment_offline=0\nmail_view_only=0\nis_use_ja_login_form=0\n\n'),
(23, 'comments', 'is_enable_threads=1\nis_allow_voting=1\ntotal_attach_file=5\nmax_size_attach_file=2\nattach_file_type=doc,docx,pdf,txt,zip,rar,jpg,bmp,gif,png\nis_enable_website_field=1\nis_enable_autoexpanding=1\nis_extra_fields_expand=1\nis_enable_email_subscription=1\nis_allow_report=1\nis_allow_approve_new_comment=1\nmaximum_comment_in_item=100\nis_enable_rss=1\n\n'),
(24, 'spamfilters', 'terms_of_usage=Registration to this forum is free! We do insist that you abide by the rules and policies detailed below. If you agree to the terms, please check the ''I agree'' checkbox and press the ''Register'' button below. If you would like to cancel the registration, click here to return to the forums index.\\n\\nForum Rules\\n\\nRegistration to this forum is free! We do insist that you abide by the rules and policies detailed below. If you agree to the terms, please check the ''I agree'' checkbox and press the ''Register'' button below. If you would like to cancel the registration, click here to return to the forums index.\nmin_length=10\nmax_length=1000\ncensored_words=\ncensored_words_replace=\nis_nofollow=1\nnumber_of_links=5\nis_enable_captcha_user=0\nis_use_akismet=0\n\n'),
(25, 'blocked_word_list', '\ndamn'),
(26, 'blacklist_word_list', '\nfuck'),
(27, 'permissions', 'view=all\npost=all\nvote=all\ntype_voting=1\nreport=all\ntotal_to_report_spam=10\ntype_editing=1\n\n'),
(28, 'layout', 'theme=default\nenable_avatar=1\ntype_avatar=0\navatar_size=3\nenable_youtube=1\nis_enable_website_field=0\nform_position=1\nenable_sorting_options=1\ndefault_sort=date\ndefault_sort_type=ASC\nenable_timestamp=1\nfooter_text=Copyright JAComment\ncustom_css=\nenable_login_rpx=1\nenable_addthis=1\ncustom_addthis=<!-- AddThis Button BEGIN -->\\n<a class="addthis_button" href="http://addthis.com/bookmark.php?v=250&pub=xa-4af3e1272f178ef0"><img src="http://s7.addthis.com/static/btn/v2/lg-share-en.gif" width="125" height="16" alt="Bookmark and Share" style="border:0"/></a><script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pub=xa-4af3e1272f178ef0"></script>\\n<!-- AddThis Button END -->\ncustom_addtoany=<a class="a2a_dd" href="http://www.addtoany.com/share_save"><img src="http://static.addtoany.com/buttons/share_save_171_16.png" width="171" height="16" border="0" alt="Share/Bookmark"/></a><script type="text/javascript">a2a_linkname=document.title;a2a_linkurl=location.href;</script><script type="text/javascript" src="http://static.addtoany.com/menu/page.js"></script>\ncustom_tweetmeme=<script type="text/javascript" src="http://tweetmeme.com/i/scripts/button.js"></script>\nenable_bbcode=1\nenable_smileys=1\nuse_default_avatar=0\nenable_login_button=0\nenable_subscribe_menu=0\nenable_user_rep_indicator=0\nenable_comment_form=0\nenable_addtoany=1\nenable_polldaddy=0\nenable_seesmic=0\nenable_tweetmeme=1\nenable_activity_stream=1\n\n');

-- --------------------------------------------------------

--
-- Table structure for table `jos_jacomment_email_templates`
--

CREATE TABLE IF NOT EXISTS `jos_jacomment_email_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `title` varchar(525) DEFAULT NULL,
  `subject` varchar(525) DEFAULT NULL,
  `content` text,
  `email_from_address` varchar(255) DEFAULT NULL,
  `email_from_name` varchar(255) DEFAULT NULL,
  `published` tinyint(1) DEFAULT '0',
  `group` int(11) DEFAULT '0',
  `language` varchar(20) DEFAULT NULL,
  `system` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `jos_jacomment_email_templates`
--

INSERT INTO `jos_jacomment_email_templates` (`id`, `name`, `title`, `subject`, `content`, `email_from_address`, `email_from_name`, `published`, `group`, `language`, `system`) VALUES
(10, 'mailheader', 'Header', 'Header', '', '', '', 1, 1, 'en-GB', 1),
(11, 'mailfooter', 'Footer', 'Footer', '<p style="margin: 15px 5px 2px 0pt; text-align: right; color: #aaaaaa"> powered by <span style="font-family: arial; font-style: normal; font-variant: normal; font-weight: normal; font-size: 16px; line-height: normal; font-size-adjust: none; font-stretch: normal; letter-spacing: -1px"><strong>JA<font color="#f47414">Comment</font></strong></span> </p>', '', '', 1, 1, 'en-GB', 1),
(35, 'Jacommentconfirmation_sent_to_new_comment_creator_need_admin_approved', 'Confirmation sent to new comment creator - In cases where admin approval is Required', 'Your comment is pending approval...', '<p>Dear {USERS_USERNAME}, </p><p>This email is to inform that you have just created a new comment on the issue {ITEM_TITLE_WITH_LINK} at {CONFIG.SITE_TITLE} with the following details: </p><p><strong>Comment URL</strong>: {ITEM_LINK} </p><p><strong>Comment details</strong>: {ITEM_DETAILS}.</p><p> Your comment shall be posted after being approved by administrator. Please check your mailbox periodically for updated information. </p><p>Sincerely, {CONFIG.SITE_TITLE}</p>', '', '', 1, 0, 'en-GB', 0),
(12, 'Jacommentnotify_to_user_new_voice_daily', 'Dailly NEW Comment statistics (to those who subscribe)', '[JA Comment] Daily statistics', '<p>Hi {USERS_USERNAME},</p><p>Here are a quick overview of what has been going on at JA Comment during the last 24 hours: </p>{ITEM_DETAILS}', '', '', 1, 0, 'en-GB', 1),
(19, 'Jacommentnotify_when_new_item_was_post', 'Notify when new item was post', 'Have a new comment!', '<p>Dear {USERS_USERNAME}, </p><p>This email is to inform that a comment has been newly added into the issue {ITEM_TITLE_WITH_LINK} at {CONFIG.SITE_TITLE} with the following details: </p><p><strong>Comment URL:</strong> {ITEM_LINK} </p><p><strong>Comment details:</strong> {ITEM_DETAILS} </p><p>Please click on the link above to view the full details. </p><p>Sincerely, {CONFIG.SITE_TITLE}</p>', '', '', 1, 0, 'en-GB', 0),
(22, 'Jacommentnotifying_admin_on_a_new_comment_posted', 'Notifying admin on a new comment posted', 'A new comment has been newly added', '<p>Dear {USERS_USERNAME}, </p><p>This email is to inform you that a new comment on {ITEM_TITLE_WITH_LINK} has newly been added at {CONFIG.SITE_TITLE} with the following details: </p><p><strong>Comment URL:</strong> {ITEM_LINK} </p><p><strong>Comment details:</strong> {ITEM_DETAILS} </p><p><strong>Comment creator:</strong> {ITEM_CREATE_BY} </p><p>Please review the above comments and take appropriate actions as soon as possible. </p><p>Yours sincerely, {CONFIG.SITE_TITLE}</p>', '', '', 1, 0, 'en-GB', 0),
(34, 'Jacommentconfirmation_sent_to_new_comment_creator_dont_need_admin_approved', 'Confirmation sent to new comment creator - In cases where admin approval is NOT required', 'We confirm your comment', '<p>Dear {USERS_USERNAME}, </p><p>This email is to confirm that you have successfully created a new comment on the issue {ITEM_TITLE_WITH_LINK} at {CONFIG.SITE_TITLE} with the following details: </p><p> <strong>Comment URL:</strong> {ITEM_LINK} </p><p><strong>Comment details:</strong> {ITEM_DETAILS}.</p><p>Please check your mailbox periodically as we shall notify you if there is any new reply on this issue.</p><p> Sincerely, {CONFIG.SITE_TITLE}</p>', '', '', 1, 0, 'en-GB', 0),
(24, 'Jacommentnotifying_comment_creator_if_there_is_a_new_reply_to_his_comment', 'Notifying comment creator if there is a new reply to his comment', 'A new reply has just been posted on your comment', '<p>Dear {USERS_USERNAME}, </p><p>This email is to inform that a new reply has just been posted on the issue {ITEM_TITLE_WITH_LINK} at {CONFIG.SITE_TITLE} with the following details: </p><p><strong>Reply URL</strong>: {ITEM_LINK} </p><p><strong>Reply details</strong>: {ITEM_DETAILS} </p><p><strong>Reply creator:</strong> {REPLY_OWNER} . </p><p>Yours sincerely, {CONFIG.SITE_TITLE}</p>', '', '', 1, 0, 'en-GB', 0),
(25, 'Jacommentnotifying_those_whose_comment_has_been_deleted', 'Notifying those whose comment has been deleted', 'Your comment has been deleted', '<p>Dear {USERS_USERNAME}, </p><p>We are sorry to inform that your comment on the issue "{ITEM_TITLE_WITH_LINK}', '', '', 1, 0, 'en-GB', 0),
(26, 'Jacommentnotifying_those_whose_comment_has_been_approved', 'Notifying those whose comment has been approved', 'Your Comment has been approved', '<p>Dear {USERS_USERNAME}, </p><p> This email is to inform that your comment on the issue {ITEM_TITLE_WITH_LINK} at {CONFIG.SITE_TITLE} has been approved and published by {SITE_ADMIN} with the following details: </p><p><strong>Comment URL:</strong> {ITEM_LINK} </p><p><strong>Comment details:</strong> {ITEM_DETAILS} </p><p>Please check your mailbox periodically as we shall notify you if there is any reply on this issue Yours. sincerely, {CONFIG.SITE_TITLE}</p>', '', '', 1, 0, 'en-GB', 0),
(27, 'Jacommentnotifying_admin_of_a_spam_report_on_a_comment', 'Notifying admin of a spam report on a comment', 'A comment has been reported as spam', '<p>Dear {USERS_USERNAME}, </p><p>This email is to inform that the comment on the issue {ITEM_TITLE_WITH_LINK} at {CONFIG.SITE_TITLE} has been reported as spam recently. </p><p><strong>Comment URL:</strong> {ITEM_LINK} </p><p><strong>Comment details:</strong> {ITEM_DETAILS} </p><p><strong>Spam reporter:</strong> {SPAM_REPORTER} </p><p>Kindly review the above comment to see if it is a spam as report or not for further action at your soonest time. </p><p>Yours sincerely, {CONFIG.SITE_TITLE}</p>', '', '', 1, 0, 'en-GB', 0),
(28, 'Jacommentnotifying_those_whose_comment_is_reported_as_spam', 'Notifying those whose comment is reported as spam', 'You have comment reported as spam', '<p>Dear {USERS_USERNAME}, </p><p>This email is to inform that your comment on the issue {ITEM_TITLE_WITH_LINK} at {CONFIG.SITE_TITLE} has been reported as spam by other user recently. </p><p><strong>Comment URL:</strong> {ITEM_LINK} </p><p><strong>Comment details:</strong> {ITEM_DETAILS} </p><p><strong>Spam reporter:</strong> {SPAM_REPORTER} </p><p>The spam report shall be thoroughly and fairly reviewed by {SITE_ADMIN} before any further action. Kindly continue using our site normally and sorry for any inconveniences that may have caused. </p><p>Yours sincerely, {CONFIG.SITE_TITLE}</p>', '', '', 1, 0, 'en-GB', 0),
(29, 'Jacommentnotifying_those_whose_comment_is_removed_as_spam_by_admin', 'Notifying those whose comment is removed as spam by admin', 'Your comment has been removed as spam by administrator', '<p>Dear {USERS_USERNAME},</p><p>This email is to inform that your comment on the issue {ITEM_TITLE_WITH_LINK} at {CONFIG.SITE_TITLE} has been removed as spam by {SITE_ADMIN}. </p><p><strong>Comment URL:</strong> {ITEM_LINK} </p><p><strong>Comment details:</strong> {ITEM_DETAILS} </p><p><strong>Moderate Reasons:</strong> {MOD_REASONS} </p><p> Thank you for your understanding and do hope you carefully read the instructions and strictly follow the Terms of Use before posting any comments at {CONFIG.SITE_TITLE} in the time to come.</p><p> Yours sincerely, {CONFIG.SITE_TITLE}</p>', '', '', 1, 0, 'en-GB', 0),
(30, 'Jacommentnotifying_those_whose_comment_has_been_unapproved', 'Notifying those whose comment has been unapproved', 'You have a comment unapproved', '<p>Dear {USERS_USERNAME}, </p><p>This email is to inform that your comment on the issue {ITEM_TITLE_WITH_LINK} at {CONFIG.SITE_TITLE} has been unapproved by {SITE_ADMIN} due to the following reasons:</p><p> <strong>Comment URL:</strong> {ITEM_LINK} </p><p><strong>Comment details:</strong> {ITEM_DETAILS} </p><p><strong>Unapproved reasons:</strong> {UNAPPROVE_REASONS} </p><p>Thank you for your understanding and do hope you carefully read the instructions and strictly follow the Terms of Use before posting any comments at {CONFIG.SITE_TITLE} in the time to come. </p><p>Yours sincerely, {CONFIG.SITE_TITLE}</p>', '', '', 1, 0, 'en-GB', 0),
(32, 'Jacommentnotifying_comment_creator_if_there_is_a_new_comment_on_the_issue', 'Notifying comment creator if there is a new comment on the issue', 'A new comment has been added', '<p>Dear {USERS_USERNAME}, </p><p>This email is to inform that a comment has been newly added into the issue {ITEM_TITLE_WITH_LINK} at {CONFIG.SITE_TITLE} with the following details:</p><p> <strong>Comment URL:</strong> {ITEM_LINK} </p><p><strong>Comment details:</strong> {ITEM_DETAILS} </p><p>Please click on the link above to view the full details. </p><p>Sincerely, {CONFIG.SITE_TITLE}</p>', '', '', 1, 0, 'en-GB', 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_jacomment_items`
--

CREATE TABLE IF NOT EXISTS `jos_jacomment_items` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `parentid` int(11) NOT NULL DEFAULT '0',
  `contentid` int(10) NOT NULL DEFAULT '0',
  `ip` varchar(15) NOT NULL DEFAULT '',
  `name` varchar(200) DEFAULT NULL,
  `contenttitle` varchar(200) NOT NULL DEFAULT '',
  `comment` text NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `email` varchar(100) NOT NULL DEFAULT '',
  `website` varchar(100) NOT NULL DEFAULT '',
  `star` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `usertype` mediumtext NOT NULL,
  `option` varchar(50) NOT NULL DEFAULT 'com_content',
  `voted` smallint(6) NOT NULL DEFAULT '0',
  `report` smallint(6) NOT NULL DEFAULT '0',
  `subscription_type` tinyint(4) NOT NULL DEFAULT '0',
  `referer` varchar(255) NOT NULL DEFAULT '',
  `source` varchar(20) NOT NULL,
  `type` tinyint(4) DEFAULT NULL,
  `date_active` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `option` (`option`),
  KEY `contentid` (`contentid`),
  KEY `published` (`published`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `jos_jacomment_items`
--

INSERT INTO `jos_jacomment_items` (`id`, `parentid`, `contentid`, `ip`, `name`, `contenttitle`, `comment`, `date`, `published`, `locked`, `ordering`, `email`, `website`, `star`, `userid`, `usertype`, `option`, `voted`, `report`, `subscription_type`, `referer`, `source`, `type`, `date_active`) VALUES
(1, 0, 5, '::1', 'fsdfsdf', 'Tấm lòng vàng', 'asdfasdfasdfasdfasdffsdf', '2010-08-09 03:44:57', 1, 0, 0, 'thtinh@vxg.vn', '', 0, 0, '', 'com_content', 1, 0, 0, 'index.php?option=com_content&view=article&id=5&Itemid=10#jacommentid:1', '', 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `jos_jacomment_logs`
--

CREATE TABLE IF NOT EXISTS `jos_jacomment_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `itemid` int(11) DEFAULT NULL,
  `votes` int(4) NOT NULL DEFAULT '0',
  `reports` int(4) NOT NULL DEFAULT '0',
  `time_expired` int(11) DEFAULT NULL,
  `remote_addr` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=428 ;

--
-- Dumping data for table `jos_jacomment_logs`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_menu`
--

CREATE TABLE IF NOT EXISTS `jos_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menutype` varchar(75) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `link` text,
  `type` varchar(50) NOT NULL DEFAULT '',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `parent` int(11) unsigned NOT NULL DEFAULT '0',
  `componentid` int(11) unsigned NOT NULL DEFAULT '0',
  `sublevel` int(11) DEFAULT '0',
  `ordering` int(11) DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pollid` int(11) NOT NULL DEFAULT '0',
  `browserNav` tinyint(4) DEFAULT '0',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `utaccess` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `lft` int(11) unsigned NOT NULL DEFAULT '0',
  `rgt` int(11) unsigned NOT NULL DEFAULT '0',
  `home` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `componentid` (`componentid`,`menutype`,`published`,`access`),
  KEY `menutype` (`menutype`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `jos_menu`
--

INSERT INTO `jos_menu` (`id`, `menutype`, `name`, `alias`, `link`, `type`, `published`, `parent`, `componentid`, `sublevel`, `ordering`, `checked_out`, `checked_out_time`, `pollid`, `browserNav`, `access`, `utaccess`, `params`, `lft`, `rgt`, `home`) VALUES
(1, 'mainmenu', 'Trang chủ', 'trang-chu', 'index.php?option=com_content&view=frontpage', 'component', 1, 0, 20, 0, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 3, 'num_leading_articles=1\nnum_intro_articles=4\nnum_columns=2\nnum_links=4\norderby_pri=\norderby_sec=front\nmulti_column_order=1\nshow_pagination=2\nshow_pagination_results=1\nshow_feed_link=1\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=Trang chủ\nshow_page_title=0\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 1),
(2, 'mainmenu', 'Giới thiệu', 'gioi-thieu', 'index.php?option=com_content&view=article&id=90', 'component', 1, 0, 20, 0, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=0\nshow_create_date=0\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=0\nshow_pdf_icon=0\nshow_print_icon=0\nshow_email_icon=0\nshow_hits=0\nfeed_summary=\npage_title=Giới thiệu\nshow_page_title=1\npageclass_sfx=_introduction\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(3, 'mainmenu', 'Lịch sử thành lập', 'lich-su-thanh-lap', 'index.php?option=com_content&view=article&id=94', 'component', 1, 2, 20, 1, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=0\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=0\nshow_pdf_icon=0\nshow_print_icon=0\nshow_email_icon=0\nshow_hits=0\nfeed_summary=\npage_title=Lịch sử thành lập\nshow_page_title=1\npageclass_sfx=_history\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(4, 'mainmenu', 'Các hoạt động', 'cac-hoat-dong', '', 'url', 1, 2, 0, 1, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(5, 'mainmenu', 'Tổ chức', 'to-chuc', '', 'url', 1, 2, 0, 1, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(6, 'mainmenu', 'Đào tạo - Nghiên cứu', 'dao-tao-nghien-cuu', '', 'url', 1, 2, 0, 1, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(7, 'mainmenu', 'Tin tức', 'tin-tuc', '', 'url', 1, 0, 0, 0, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(8, 'mainmenu', 'Thời sự - Phóng sự', 'thoi-su-phong-su', 'index.php?option=com_content&view=category&layout=blog&id=3', 'component', 1, 7, 20, 1, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_description=0\nshow_description_image=0\nnum_leading_articles=0\nnum_intro_articles=4\nnum_columns=1\nnum_links=4\norderby_pri=\norderby_sec=\nmulti_column_order=0\nshow_pagination=2\nshow_pagination_results=1\nshow_feed_link=1\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_item_navigation=\nshow_readmore=\nshow_vote=0\nshow_icons=\nshow_pdf_icon=0\nshow_print_icon=\nshow_email_icon=\nshow_hits=0\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(9, 'mainmenu', 'Thông tin khoa học', 'thong-tin-khoa-hoc', '', 'url', 1, 7, 0, 1, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(10, 'mainmenu', 'Tấm lòng vàng', 'tam-long-vang', 'index.php?option=com_content&view=article&id=5', 'component', 1, 7, 20, 1, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=_sponsor\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(11, 'mainmenu', 'Ký sự', 'ky-su', '', 'url', 1, 7, 0, 1, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(12, 'mainmenu', 'Nhịp cầu trái tim', 'nhip-cau-trai-tim', 'index.php?option=com_content&view=category&layout=blog&id=7', 'component', 1, 7, 20, 1, 5, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_description=0\nshow_description_image=0\nnum_leading_articles=1\nnum_intro_articles=0\nnum_columns=1\nnum_links=0\norderby_pri=\norderby_sec=\nmulti_column_order=0\nshow_pagination=2\nshow_pagination_results=1\nshow_feed_link=1\nshow_noauth=\nshow_title=0\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_item_navigation=\nshow_readmore=\nshow_vote=0\nshow_icons=0\nshow_pdf_icon=0\nshow_print_icon=0\nshow_email_icon=0\nshow_hits=0\nfeed_summary=\npage_title=Nhịp cầu trái tim\nshow_page_title=1\npageclass_sfx=_heart\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(13, 'mainmenu', 'Sổ lưu niệm', 'so-luu-niem', 'index.php?option=com_content&view=category&layout=blog&id=10', 'component', 1, 0, 20, 0, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_description=0\nshow_description_image=0\nnum_leading_articles=0\nnum_intro_articles=3\nnum_columns=1\nnum_links=0\norderby_pri=\norderby_sec=\nmulti_column_order=0\nshow_pagination=2\nshow_pagination_results=1\nshow_feed_link=1\nshow_noauth=\nshow_title=0\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_item_navigation=0\nshow_readmore=\nshow_vote=0\nshow_icons=0\nshow_pdf_icon=0\nshow_print_icon=0\nshow_email_icon=0\nshow_hits=0\nfeed_summary=\npage_title=Sổ lưu niệm\nshow_page_title=1\npageclass_sfx=_souvenir\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(14, 'mainmenu', 'Thư viện Ảnh', 'thu-vien-anh', 'index.php?option=com_phocagallery&view=category&id=2', 'component', 1, 0, 57, 0, 5, 62, '2010-08-19 06:59:57', 0, 0, 0, 0, 'show_pagination_categories=1\nshow_pagination_category=1\nshow_pagination_limit_categories=1\nshow_pagination_limit_category=1\ndisplay_cat_name_title=0\ndisplay_cat_name_breadcrumbs=0\ncategories_columns=\nequal_percentage_width=\ndisplay_image_categories=0\ncategories_box_width=\nimage_categories_size=\ncategories_image_ordering=\ncategories_display_avatar=\ndisplay_subcategories=\ndisplay_empty_categories=\nhide_categories=\nshow_categories=\ndisplay_access_category=\ndefault_pagination_categories=\npagination_categories=\nfont_color=\nbackground_color=\nbackground_color_hover=\nimage_background_color=\nimage_background_shadow=\nborder_color=\nborder_color_hover=\nmargin_box=\npadding_box=\ndisplay_new=\ndisplay_hot=\ndisplay_name=\ndisplay_icon_detail=\ndisplay_icon_download=\ndisplay_icon_folder=\nfont_size_name=\nchar_length_name=\ncategory_box_space=\ndisplay_categories_sub=\ndisplay_subcat_page=\ndisplay_category_icon_image=\ncategory_image_ordering=\ndisplay_back_button=\ndisplay_categories_back_button=\ndefault_pagination_category=\npagination_category=\ndisplay_img_desc_box=\nfont_size_img_desc=\nimg_desc_box_height=\nchar_length_img_desc=\ndisplay_categories_cv=\ndisplay_subcat_page_cv=\ndisplay_category_icon_image_cv=\ncategory_image_ordering_cv=\ndisplay_back_button_cv=\ndisplay_categories_back_button_cv=\ncategories_columns_cv=\ndisplay_image_categories_cv=\nimage_categories_size_cv=\ndetail_window=\ndetail_window_background_color=\nmodal_box_overlay_color=\nmodal_box_overlay_opacity=\nmodal_box_border_color=\nmodal_box_border_width=\nsb_slideshow_delay=\nsb_lang=\nhighslide_class=\nhighslide_opacity=\nhighslide_outline_type=\nhighslide_fullimg=\nhighslide_close_button=\nhighslide_slideshow=\njak_slideshow_delay=\njak_orientation=\njak_description=\njak_description_height=\ndisplay_description_detail=\ndisplay_title_description=\nfont_size_desc=\nfont_color_desc=\ndescription_detail_height=\ndescription_lightbox_font_size=\ndescription_lightbox_font_color=\ndescription_lightbox_bg_color=\nslideshow_delay=\nslideshow_pause=\nslideshow_random=\ndetail_buttons=\nphocagallery_width=\nphocagallery_center=\ncategory_ordering=\nimage_ordering=\ngallery_metadesc=\ngallery_metakey=\nalt_value=\nenable_user_cp=\nenable_upload_avatar=\nenable_avatar_approve=\nenable_usercat_approve=\nenable_usersubcat_approve=\nuser_subcat_count=\nmax_create_cat_char=\nenable_userimage_approve=\nmax_upload_char=\nupload_maxsize=\nupload_maxres_width=\nupload_maxres_height=\nuser_images_max_size=\nenable_java=\nenable_java_admin=\njava_resize_width=\njava_resize_height=\njava_box_width=\njava_box_height=\ndisplay_rating=\ndisplay_rating_img=\ndisplay_comment=\ndisplay_comment_img=\ncomment_width=\nmax_comment_char=\nexternal_comment_system=\nenable_piclens=\nstart_piclens=\npiclens_image=\nswitch_image=\nswitch_width=\nswitch_height=\nswitch_fixed_size=\nenable_overlib=\nol_bg_color=\nol_fg_color=\nol_tf_color=\nol_cf_color=\noverlib_overlay_opacity=\noverlib_image_rate=\ncreate_watermark=\nwatermark_position_x=\nwatermark_position_y=\ndisplay_icon_vm=\ndisplay_category_statistics=\ndisplay_main_cat_stat=\ndisplay_lastadded_cat_stat=\ncount_lastadded_cat_stat=\ndisplay_mostviewed_cat_stat=\ncount_mostviewed_cat_stat=\ndisplay_camera_info=\nexif_information=\ndisplay_categories_geotagging=\ncategories_lng=\ncategories_lat=\ncategories_zoom=\ncategories_map_width=\ncategories_map_height=\ndisplay_icon_geotagging=\ndisplay_category_geotagging=\ncategory_map_width=\ncategory_map_height=\npagination_thumbnail_creation=\nclean_thumbnails=\nenable_thumb_creation=\ncrop_thumbnail=\njpeg_quality=\nenable_picasa_loading=\npicasa_load_pagination=\nicon_format=\nlarge_image_width=\nlarge_image_height=\nmedium_image_width=\nmedium_image_height=\nsmall_image_width=\nsmall_image_height=\nfront_modal_box_width=\nfront_modal_box_height=\nadmin_modal_box_width=\nadmin_modal_box_height=\nfolder_permissions=\njfile_thumbs=\npage_title=Thư viện Ảnh\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(15, 'mainmenu', 'Liên hệ', 'lien-he', 'index.php?option=com_content&view=article&id=6', 'component', 1, 0, 20, 0, 6, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=1\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_item_navigation=0\nshow_readmore=0\nshow_vote=0\nshow_icons=0\nshow_pdf_icon=0\nshow_print_icon=0\nshow_email_icon=0\nshow_hits=0\nfeed_summary=\npage_title=Liên hệ\nshow_page_title=1\npageclass_sfx= contact\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_menu_types`
--

CREATE TABLE IF NOT EXISTS `jos_menu_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menutype` varchar(75) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `menutype` (`menutype`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `jos_menu_types`
--

INSERT INTO `jos_menu_types` (`id`, `menutype`, `title`, `description`) VALUES
(1, 'mainmenu', 'Main Menu', 'The main menu for the site');

-- --------------------------------------------------------

--
-- Table structure for table `jos_messages`
--

CREATE TABLE IF NOT EXISTS `jos_messages` (
  `message_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id_from` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id_to` int(10) unsigned NOT NULL DEFAULT '0',
  `folder_id` int(10) unsigned NOT NULL DEFAULT '0',
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `state` int(11) NOT NULL DEFAULT '0',
  `priority` int(1) unsigned NOT NULL DEFAULT '0',
  `subject` text NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`message_id`),
  KEY `useridto_state` (`user_id_to`,`state`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_messages`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_messages_cfg`
--

CREATE TABLE IF NOT EXISTS `jos_messages_cfg` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `cfg_name` varchar(100) NOT NULL DEFAULT '',
  `cfg_value` varchar(255) NOT NULL DEFAULT '',
  UNIQUE KEY `idx_user_var_name` (`user_id`,`cfg_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_messages_cfg`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_migration_backlinks`
--

CREATE TABLE IF NOT EXISTS `jos_migration_backlinks` (
  `itemid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `url` text NOT NULL,
  `sefurl` text NOT NULL,
  `newurl` text NOT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_migration_backlinks`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_modules`
--

CREATE TABLE IF NOT EXISTS `jos_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `position` varchar(50) DEFAULT NULL,
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `module` varchar(50) DEFAULT NULL,
  `numnews` int(11) NOT NULL DEFAULT '0',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `showtitle` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  `iscore` tinyint(4) NOT NULL DEFAULT '0',
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  `control` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `published` (`published`,`access`),
  KEY `newsfeeds` (`module`,`published`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=45 ;

--
-- Dumping data for table `jos_modules`
--

INSERT INTO `jos_modules` (`id`, `title`, `content`, `ordering`, `position`, `checked_out`, `checked_out_time`, `published`, `module`, `numnews`, `access`, `showtitle`, `params`, `iscore`, `client_id`, `control`) VALUES
(1, 'Main Menu', '', 1, 'menu', 0, '0000-00-00 00:00:00', 1, 'mod_mainmenu', 0, 0, 1, 'menutype=mainmenu\nmenu_style=list\nstartLevel=0\nendLevel=10\nshowAllChildren=1\nwindow_open=\nshow_whitespace=0\ncache=1\ntag_id=\nclass_sfx=\nmoduleclass_sfx=_menu\nmaxdepth=10\nmenu_images=0\nmenu_images_align=0\nmenu_images_link=0\nexpand_menu=1\nactivate_parent=0\nfull_active_id=0\nindent_image=0\nindent_image1=\nindent_image2=\nindent_image3=\nindent_image4=\nindent_image5=\nindent_image6=\nspacer=\nend_spacer=\n\n', 1, 0, ''),
(2, 'Login', '', 1, 'login', 0, '0000-00-00 00:00:00', 1, 'mod_login', 0, 0, 1, '', 1, 1, ''),
(3, 'Popular', '', 3, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_popular', 0, 2, 1, '', 0, 1, ''),
(4, 'Recent added Articles', '', 4, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_latest', 0, 2, 1, 'ordering=c_dsc\nuser_id=0\ncache=0\n\n', 0, 1, ''),
(5, 'Menu Stats', '', 5, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_stats', 0, 2, 1, '', 0, 1, ''),
(6, 'Unread Messages', '', 1, 'header', 0, '0000-00-00 00:00:00', 1, 'mod_unread', 0, 2, 1, '', 1, 1, ''),
(7, 'Online Users', '', 2, 'header', 0, '0000-00-00 00:00:00', 1, 'mod_online', 0, 2, 1, '', 1, 1, ''),
(8, 'Toolbar', '', 1, 'toolbar', 0, '0000-00-00 00:00:00', 1, 'mod_toolbar', 0, 2, 1, '', 1, 1, ''),
(9, 'Quick Icons', '', 1, 'icon', 0, '0000-00-00 00:00:00', 1, 'mod_quickicon', 0, 2, 1, '', 1, 1, ''),
(10, 'Logged in Users', '', 2, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_logged', 0, 2, 1, '', 0, 1, ''),
(11, 'Footer', '', 0, 'footer', 0, '0000-00-00 00:00:00', 1, 'mod_footer', 0, 0, 1, '', 1, 1, ''),
(12, 'Admin Menu', '', 1, 'menu', 0, '0000-00-00 00:00:00', 1, 'mod_menu', 0, 2, 1, '', 0, 1, ''),
(13, 'Admin SubMenu', '', 1, 'submenu', 0, '0000-00-00 00:00:00', 1, 'mod_submenu', 0, 2, 1, '', 0, 1, ''),
(14, 'User Status', '', 1, 'status', 0, '0000-00-00 00:00:00', 1, 'mod_status', 0, 2, 1, '', 0, 1, ''),
(15, 'Title', '', 1, 'title', 0, '0000-00-00 00:00:00', 1, 'mod_title', 0, 2, 1, '', 0, 1, ''),
(16, 'Banner Top', '', 1, 'top', 0, '0000-00-00 00:00:00', 1, 'mod_banners', 0, 0, 0, 'target=1\ncount=1\ncid=1\ncatid=1\ntag_search=1\nordering=0\nheader_text=\nfooter_text=\nmoduleclass_sfx=\ncache=1\ncache_time=900\n\n', 0, 0, ''),
(17, 'Banner Phải', '', 3, 'right', 0, '0000-00-00 00:00:00', 1, 'mod_banners', 0, 0, 0, 'target=1\ncount=1\ncid=1\ncatid=2\ntag_search=0\nordering=0\nheader_text=\nfooter_text=\nmoduleclass_sfx=_right\ncache=1\ncache_time=900\n\n', 0, 0, ''),
(19, 'Breadcrumbs', '', 1, 'breadcrumbs', 0, '0000-00-00 00:00:00', 1, 'mod_breadcrumbs', 0, 0, 0, 'showHome=1\nhomeText=Trang chủ\nshowLast=1\nseparator=\nmoduleclass_sfx=\ncache=0\n\n', 0, 0, ''),
(29, 'Tin thư trực tuyến', '', 1, 'contact-form', 0, '0000-00-00 00:00:00', 1, 'mod_contactUs', 0, 0, 1, 'moduleclass_sfx=_contact\n\n', 0, 0, ''),
(21, 'Tin tức', '', 4, 'right', 0, '0000-00-00 00:00:00', 1, 'mod_vxg_latestnews', 0, 0, 1, 'moduleclass_sfx=_news\ncatid=3,4,6,7\ntrimtext=100\nshowthumbnail=1\nlimit=3\n\n', 0, 0, ''),
(23, 'Tài trợ chính', '', 1, 'sponsors', 0, '0000-00-00 00:00:00', 1, 'mod_sponsors', 0, 0, 1, 'target=1\ncount=9\ncid=2\ncatid=9\ntag_search=0\nordering=0\nheader_text=\nfooter_text=\nmoduleclass_sfx=_sponsor\ncache=1\ncache_time=900\n\n', 0, 0, ''),
(25, 'Tấm lòng vàng', '', 1, 'right', 0, '0000-00-00 00:00:00', 1, 'mod_sponsors', 0, 0, 0, 'target=1\ncount=3\ncid=2\ncatid=9\ntag_search=0\nordering=0\ncarousel=1\nheader_text=Tấm lòng vàng\nfooter_text=\nmoduleclass_sfx=_right\ncache=1\ncache_time=900\n\n', 0, 0, ''),
(28, 'Album - Video Clip', '', 1, 'left', 0, '0000-00-00 00:00:00', 1, 'mod_jatabs', 0, 0, 0, 'moduleclass_sfx=hb\ntype=articlesIDs\nmodules-position=0\nmodule-modulename=mod_search, mod_login\narticlesIDs-ids=88, 89\ncategoryID-catid=8\ncontent-content=[tab title=''Title tab 1'']This is tab content 1[/tab]  [tab title=''Title tab 2'']This is tab content 2[/tab]  [tab title=''Title tab 3'']This is tab content 3[/tab]  [tab title=''Title tab 4'']This is tab content 4[/tab]\nstyle=hb\nHeight=auto\nWidth=660\nposition=top\ntHeight=\ntWidth=\nanimType=animFade\nmouseType=click\najax=1\nview=fulltext\nduration=1000\ncolors=\n\n', 0, 0, ''),
(32, 'Danh sách Tài Trợ', '', 1, 'sponsorslist', 0, '0000-00-00 00:00:00', 1, 'mod_sponsors_list', 0, 0, 1, 'catid=11\nmoduleclass_sfx=_sponsorlist\n\n', 0, 0, ''),
(33, 'Photoslide', '', 1, 'photoslide', 0, '0000-00-00 00:00:00', 1, 'mod_yoo_carousel', 0, 0, 0, 'catid=13\nstyle=slideshow\nmodule_width=650\nmodule_height=280\ntab_width=200\nautoplay=on\nslide_interval=10000\ntransition_duration=700\ntransition_effect=scroll\ncontrol_panel=top\nrotate_action=click\nrotate_duration=700\nrotate_effect=scroll\nbuttons=1\norder=rnd\nreadmore=0\nitems=4\nmoduleclass_sfx=-blank\ncache=0\ncache_time=900\n\n', 0, 0, ''),
(40, 'Custom Properties Search', '', 2, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_cpsearch', 0, 0, 1, '', 0, 0, ''),
(41, 'Custom Properties Cloud', '', 3, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_cpcloud', 0, 0, 1, '', 0, 0, ''),
(42, 'Tra cứu thông tin bé', '', 2, 'right', 0, '0000-00-00 00:00:00', 1, 'mod_application_finder', 0, 0, 1, 'moduleclass_sfx=_right finder lightcurve lightshadow\n\n', 0, 0, ''),
(43, 'Lịch sử thành lập', '', 0, 'history', 0, '0000-00-00 00:00:00', 1, 'mod_yoo_carousel', 0, 0, 0, 'catid=15\nstyle=button\nmodule_width=660\nmodule_height=auto\ntab_width=200\nautoplay=off\nslide_interval=10000\ntransition_duration=700\ntransition_effect=fade\ncontrol_panel=top\nrotate_action=click\nrotate_duration=200\nrotate_effect=fade\nbuttons=1\norder=o_asc\nreadmore=0\nitems=2\nmoduleclass_sfx=-blank\ncache=0\ncache_time=900\n\n', 0, 0, ''),
(38, 'Video Clip', '', 1, 'videoclip', 0, '0000-00-00 00:00:00', 1, 'mod_article', 0, 0, 0, 'moduleclass_sfx=\nid=3\n\n', 0, 0, ''),
(39, 'Sổ Lưu Niệm', '', 4, 'left', 0, '0000-00-00 00:00:00', 1, 'mod_vxg_latestnews', 0, 0, 1, 'moduleclass_sfx=_souvenir\ncatid=10\ntrimtext=0\nshowthumbnail=0\nshowtitle=0\nlimit=3\n\n', 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_modules_menu`
--

CREATE TABLE IF NOT EXISTS `jos_modules_menu` (
  `moduleid` int(11) NOT NULL DEFAULT '0',
  `menuid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`moduleid`,`menuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_modules_menu`
--

INSERT INTO `jos_modules_menu` (`moduleid`, `menuid`) VALUES
(1, 0),
(16, 0),
(17, 1),
(17, 2),
(17, 3),
(17, 4),
(17, 5),
(17, 6),
(17, 7),
(17, 8),
(17, 9),
(17, 10),
(17, 11),
(17, 12),
(17, 13),
(17, 15),
(19, 0),
(21, 1),
(23, 0),
(25, 1),
(25, 2),
(25, 3),
(25, 4),
(25, 5),
(25, 6),
(25, 7),
(25, 8),
(25, 9),
(25, 10),
(25, 11),
(25, 12),
(25, 13),
(25, 15),
(28, 1),
(29, 15),
(32, 0),
(33, 0),
(38, 1),
(39, 1),
(42, 2),
(42, 3),
(42, 4),
(42, 5),
(42, 6),
(42, 7),
(42, 8),
(42, 9),
(42, 10),
(42, 11),
(42, 12),
(42, 13),
(42, 15),
(43, 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_newsfeeds`
--

CREATE TABLE IF NOT EXISTS `jos_newsfeeds` (
  `catid` int(11) NOT NULL DEFAULT '0',
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `link` text NOT NULL,
  `filename` varchar(200) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `numarticles` int(11) unsigned NOT NULL DEFAULT '1',
  `cache_time` int(11) unsigned NOT NULL DEFAULT '3600',
  `checked_out` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rtl` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `published` (`published`),
  KEY `catid` (`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_newsfeeds`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_phocagallery`
--

CREATE TABLE IF NOT EXISTS `jos_phocagallery` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL DEFAULT '0',
  `sid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `filename` varchar(250) NOT NULL DEFAULT '',
  `description` text,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hits` int(11) NOT NULL DEFAULT '0',
  `latitude` varchar(20) NOT NULL DEFAULT '',
  `longitude` varchar(20) NOT NULL DEFAULT '',
  `zoom` int(3) NOT NULL DEFAULT '0',
  `geotitle` varchar(255) NOT NULL DEFAULT '',
  `videocode` text,
  `vmproductid` int(11) NOT NULL DEFAULT '0',
  `imgorigsize` int(11) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text,
  `metakey` text,
  `metadesc` text,
  `extlink1` text,
  `extlink2` text,
  `extid` varchar(255) NOT NULL DEFAULT '',
  `extl` varchar(255) NOT NULL DEFAULT '',
  `extm` varchar(255) NOT NULL DEFAULT '',
  `exts` varchar(255) NOT NULL DEFAULT '',
  `exto` varchar(255) NOT NULL DEFAULT '',
  `extw` varchar(255) NOT NULL DEFAULT '',
  `exth` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`,`published`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=64 ;

--
-- Dumping data for table `jos_phocagallery`
--

INSERT INTO `jos_phocagallery` (`id`, `catid`, `sid`, `title`, `alias`, `filename`, `description`, `date`, `hits`, `latitude`, `longitude`, `zoom`, `geotitle`, `videocode`, `vmproductid`, `imgorigsize`, `published`, `approved`, `checked_out`, `checked_out_time`, `ordering`, `params`, `metakey`, `metadesc`, `extlink1`, `extlink2`, `extid`, `extl`, `extm`, `exts`, `exto`, `extw`, `exth`) VALUES
(1, 8, 0, 'DSC00713', 'dsc00713', 'PhongTruyenThong/DSC00713.JPG', NULL, '2010-08-17 16:07:44', 0, '', '', 0, '', NULL, 0, 2496702, 1, 1, 0, '0000-00-00 00:00:00', 1, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(2, 8, 0, 'IMGP1611', 'imgp1611', 'PhongTruyenThong/IMGP1611.JPG', NULL, '2010-08-17 16:07:44', 0, '', '', 0, '', NULL, 0, 5335321, 1, 1, 0, '0000-00-00 00:00:00', 2, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(3, 8, 0, 'IMGP1736', 'imgp1736', 'PhongTruyenThong/IMGP1736.JPG', NULL, '2010-08-17 16:07:44', 0, '', '', 0, '', NULL, 0, 4964403, 1, 1, 0, '0000-00-00 00:00:00', 3, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(4, 8, 0, 'IMGP1737', 'imgp1737', 'PhongTruyenThong/IMGP1737.JPG', NULL, '2010-08-17 16:07:44', 0, '', '', 0, '', NULL, 0, 4523982, 1, 1, 0, '0000-00-00 00:00:00', 4, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(5, 8, 0, 'IMGP1874', 'imgp1874', 'PhongTruyenThong/IMGP1874.JPG', NULL, '2010-08-17 16:08:15', 0, '', '', 0, '', NULL, 0, 5213114, 1, 1, 0, '0000-00-00 00:00:00', 5, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(6, 8, 0, 'P1000483', 'p1000483', 'PhongTruyenThong/P1000483.JPG', NULL, '2010-08-17 16:08:15', 0, '', '', 0, '', NULL, 0, 1807029, 1, 1, 0, '0000-00-00 00:00:00', 6, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(7, 8, 0, 'P1000493', 'p1000493', 'PhongTruyenThong/P1000493.JPG', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt. (Ảnh: Làng Hòa Bình)</p>', '2010-08-17 16:08:15', 0, '', '', 0, '', '', 0, 2264034, 1, 1, 0, '0000-00-00 00:00:00', 7, NULL, '', '', '', '', '', '', '', '', '', '', ''),
(8, 8, 0, 'So VHTT Tp.HCM', 'so-vhtt-tphcm', 'PhongTruyenThong/So VHTT Tp.HCM.JPG', '<p>Sở Văn Hóa Thông Tin đến thăm và tặng quà cho trẻ em ở Làng Hòa Bình. (Ảnh: Làng Hòa Bình)</p>', '2010-08-17 16:08:15', 0, '', '', 0, '', '', 0, 3635016, 1, 1, 0, '0000-00-00 00:00:00', 8, NULL, '', '', '', '', '', '', '', '', '', '', ''),
(9, 6, 0, 'DSC00015', 'dsc00015', 'poster_hb/DSC00015.JPG', NULL, '2010-08-17 16:15:38', 3, '', '', 0, '', NULL, 0, 1882580, 1, 1, 0, '0000-00-00 00:00:00', 1, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(10, 6, 0, 'DSC00016', 'dsc00016', 'poster_hb/DSC00016.JPG', NULL, '2010-08-17 16:15:38', 1, '', '', 0, '', NULL, 0, 1804521, 1, 1, 0, '0000-00-00 00:00:00', 2, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(11, 6, 0, 'DSC00017', 'dsc00017', 'poster_hb/DSC00017.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 1758677, 1, 1, 0, '0000-00-00 00:00:00', 3, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(12, 6, 0, 'DSC00041', 'dsc00041', 'poster_hb/DSC00041.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 2035128, 1, 1, 0, '0000-00-00 00:00:00', 4, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(13, 6, 0, 'DSC00042', 'dsc00042', 'poster_hb/DSC00042.JPG', NULL, '2010-08-17 16:15:38', 1, '', '', 0, '', NULL, 0, 1876544, 1, 1, 0, '0000-00-00 00:00:00', 5, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(14, 6, 0, 'DSC00043', 'dsc00043', 'poster_hb/DSC00043.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 1849929, 1, 1, 0, '0000-00-00 00:00:00', 6, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(15, 6, 0, 'DSC00044', 'dsc00044', 'poster_hb/DSC00044.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 1806170, 1, 1, 0, '0000-00-00 00:00:00', 7, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(16, 6, 0, 'DSC00045', 'dsc00045', 'poster_hb/DSC00045.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 2190276, 1, 1, 0, '0000-00-00 00:00:00', 8, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(17, 6, 0, 'DSC00046', 'dsc00046', 'poster_hb/DSC00046.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 2245891, 1, 1, 0, '0000-00-00 00:00:00', 9, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(18, 6, 0, 'DSC00047', 'dsc00047', 'poster_hb/DSC00047.JPG', NULL, '2010-08-17 16:15:38', 2, '', '', 0, '', NULL, 0, 1968756, 1, 1, 0, '0000-00-00 00:00:00', 10, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(19, 6, 0, 'DSC00048', 'dsc00048', 'poster_hb/DSC00048.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 2086026, 1, 1, 0, '0000-00-00 00:00:00', 11, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(20, 6, 0, 'DSC00049', 'dsc00049', 'poster_hb/DSC00049.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 1935917, 1, 1, 0, '0000-00-00 00:00:00', 12, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(21, 6, 0, 'DSC00050', 'dsc00050', 'poster_hb/DSC00050.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 2149083, 1, 1, 0, '0000-00-00 00:00:00', 13, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(22, 6, 0, 'DSC00051', 'dsc00051', 'poster_hb/DSC00051.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 2104195, 1, 1, 0, '0000-00-00 00:00:00', 14, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(23, 6, 0, 'DSC00052', 'dsc00052', 'poster_hb/DSC00052.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 1736051, 1, 1, 0, '0000-00-00 00:00:00', 15, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(24, 6, 0, 'DSC00053', 'dsc00053', 'poster_hb/DSC00053.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 1750336, 1, 1, 0, '0000-00-00 00:00:00', 16, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(25, 6, 0, 'DSC00054', 'dsc00054', 'poster_hb/DSC00054.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 1711038, 1, 1, 0, '0000-00-00 00:00:00', 17, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(26, 6, 0, 'DSC00059', 'dsc00059', 'poster_hb/DSC00059.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 1646915, 1, 1, 0, '0000-00-00 00:00:00', 18, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(27, 6, 0, 'DSC00060', 'dsc00060', 'poster_hb/DSC00060.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 1804111, 1, 1, 0, '0000-00-00 00:00:00', 19, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(28, 6, 0, 'DSC00061', 'dsc00061', 'poster_hb/DSC00061.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 1692801, 1, 1, 0, '0000-00-00 00:00:00', 20, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(29, 6, 0, 'DSC00062', 'dsc00062', 'poster_hb/DSC00062.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 1731773, 1, 1, 0, '0000-00-00 00:00:00', 21, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(30, 6, 0, 'DSC00063', 'dsc00063', 'poster_hb/DSC00063.JPG', NULL, '2010-08-17 16:15:38', 1, '', '', 0, '', NULL, 0, 1926181, 1, 1, 0, '0000-00-00 00:00:00', 22, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(31, 6, 0, 'DSC00064', 'dsc00064', 'poster_hb/DSC00064.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 1814045, 1, 1, 0, '0000-00-00 00:00:00', 23, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(32, 6, 0, 'DSC00065', 'dsc00065', 'poster_hb/DSC00065.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 2051202, 1, 1, 0, '0000-00-00 00:00:00', 24, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(33, 6, 0, 'DSC00066', 'dsc00066', 'poster_hb/DSC00066.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 2031856, 1, 1, 0, '0000-00-00 00:00:00', 25, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(34, 6, 0, 'DSC00067', 'dsc00067', 'poster_hb/DSC00067.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 2040536, 1, 1, 0, '0000-00-00 00:00:00', 26, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(35, 6, 0, 'DSC00068', 'dsc00068', 'poster_hb/DSC00068.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 1792641, 1, 1, 0, '0000-00-00 00:00:00', 27, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(36, 6, 0, 'DSC00069', 'dsc00069', 'poster_hb/DSC00069.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 1686879, 1, 1, 0, '0000-00-00 00:00:00', 28, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(37, 6, 0, 'DSC00070', 'dsc00070', 'poster_hb/DSC00070.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 1758253, 1, 1, 0, '0000-00-00 00:00:00', 29, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(38, 6, 0, 'DSC00071', 'dsc00071', 'poster_hb/DSC00071.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 1950946, 1, 1, 0, '0000-00-00 00:00:00', 30, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(39, 6, 0, 'DSC00072', 'dsc00072', 'poster_hb/DSC00072.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 1959639, 1, 1, 0, '0000-00-00 00:00:00', 31, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(40, 6, 0, 'DSC00073', 'dsc00073', 'poster_hb/DSC00073.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 1993312, 1, 1, 0, '0000-00-00 00:00:00', 32, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(41, 6, 0, 'DSC00074', 'dsc00074', 'poster_hb/DSC00074.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 1807732, 1, 1, 0, '0000-00-00 00:00:00', 33, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(42, 6, 0, 'DSC00075', 'dsc00075', 'poster_hb/DSC00075.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 2134258, 1, 1, 0, '0000-00-00 00:00:00', 34, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(43, 6, 0, 'DSC00076', 'dsc00076', 'poster_hb/DSC00076.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 2122516, 1, 1, 0, '0000-00-00 00:00:00', 35, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(44, 6, 0, 'DSC00077', 'dsc00077', 'poster_hb/DSC00077.JPG', NULL, '2010-08-17 16:15:38', 0, '', '', 0, '', NULL, 0, 2117306, 1, 1, 0, '0000-00-00 00:00:00', 36, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(45, 7, 0, 'DSC00009', 'dsc00009', 'poster_hb/DSC00009.JPG', NULL, '2010-08-17 16:16:01', 2, '', '', 0, '', NULL, 0, 1888596, 1, 1, 0, '0000-00-00 00:00:00', 1, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(46, 7, 0, 'DSC00010', 'dsc00010', 'poster_hb/DSC00010.JPG', NULL, '2010-08-17 16:16:01', 1, '', '', 0, '', NULL, 0, 1867363, 1, 1, 0, '0000-00-00 00:00:00', 2, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(47, 7, 0, 'DSC00011', 'dsc00011', 'poster_hb/DSC00011.JPG', NULL, '2010-08-17 16:16:01', 0, '', '', 0, '', NULL, 0, 1875733, 1, 1, 0, '0000-00-00 00:00:00', 3, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(48, 7, 0, 'DSC00012', 'dsc00012', 'poster_hb/DSC00012.JPG', NULL, '2010-08-17 16:16:01', 0, '', '', 0, '', NULL, 0, 2076021, 1, 1, 0, '0000-00-00 00:00:00', 4, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(49, 7, 0, 'DSC00013', 'dsc00013', 'poster_hb/DSC00013.JPG', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt. (Ảnh: Làng Hòa Bình)</p>', '2010-08-17 16:16:01', 2, '', '', 0, '', '', 0, 1671663, 1, 1, 0, '0000-00-00 00:00:00', 5, NULL, '', '', '', '', '', '', '', '', '', '', ''),
(50, 7, 0, 'DSC00014', 'dsc00014', 'poster_hb/DSC00014.JPG', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt. (Ảnh: Làng Hòa Bình)</p>', '2010-08-17 16:16:01', 0, '', '', 0, '', '', 0, 2237617, 1, 1, 0, '0000-00-00 00:00:00', 6, NULL, '', '', '', '', '', '', '', '', '', '', ''),
(51, 9, 0, 'DSC00713', 'dsc00713', 'PhongTruyenThong/DSC00713.JPG', NULL, '2010-08-25 13:57:09', 0, '', '', 0, '', NULL, 0, 2496702, 1, 1, 0, '0000-00-00 00:00:00', 1, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(52, 9, 0, 'IMGP1611', 'imgp1611', 'PhongTruyenThong/IMGP1611.JPG', NULL, '2010-08-25 13:57:09', 0, '', '', 0, '', NULL, 0, 5335321, 1, 1, 0, '0000-00-00 00:00:00', 2, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(53, 9, 0, 'IMGP1736', 'imgp1736', 'PhongTruyenThong/IMGP1736.JPG', NULL, '2010-08-25 13:57:09', 0, '', '', 0, '', NULL, 0, 4964403, 1, 1, 0, '0000-00-00 00:00:00', 3, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(54, 4, 0, 'DSC00015', 'dsc00015', 'poster_hb/DSC00015.JPG', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt. (Ảnh: Làng Hòa Bình)</p>', '2010-08-25 14:10:47', 0, '', '', 0, '', '', 0, 1882580, 1, 1, 0, '0000-00-00 00:00:00', 1, NULL, '', '', '', '', '', '', '', '', '', '', ''),
(55, 4, 0, 'DSC00016', 'dsc00016', 'poster_hb/DSC00016.JPG', NULL, '2010-08-25 14:10:47', 0, '', '', 0, '', NULL, 0, 1804521, 1, 1, 0, '0000-00-00 00:00:00', 2, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(56, 4, 0, 'DSC00017', 'dsc00017', 'poster_hb/DSC00017.JPG', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt. (Ảnh: Làng Hòa Bình)</p>', '2010-08-25 14:10:47', 0, '', '', 0, '', '', 0, 1758677, 1, 1, 0, '0000-00-00 00:00:00', 3, NULL, '', '', '', '', '', '', '', '', '', '', ''),
(57, 4, 0, 'DSC00041', 'dsc00041', 'poster_hb/DSC00041.JPG', NULL, '2010-08-25 14:10:47', 0, '', '', 0, '', NULL, 0, 2035128, 1, 1, 0, '0000-00-00 00:00:00', 4, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(58, 4, 0, 'DSC00042', 'dsc00042', 'poster_hb/DSC00042.JPG', NULL, '2010-08-25 14:10:47', 0, '', '', 0, '', NULL, 0, 1876544, 1, 1, 0, '0000-00-00 00:00:00', 5, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(59, 4, 0, 'DSC00043', 'dsc00043', 'poster_hb/DSC00043.JPG', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt. (Ảnh: Làng Hòa Bình)</p>', '2010-08-25 14:10:47', 0, '', '', 0, '', '', 0, 1849929, 1, 1, 0, '0000-00-00 00:00:00', 6, NULL, '', '', '', '', '', '', '', '', '', '', ''),
(60, 5, 0, 'IMGP1736', 'imgp1736', 'PhongTruyenThong/IMGP1736.JPG', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt. (Ảnh: Làng Hòa Bình)</p>', '2010-08-25 14:13:39', 0, '', '', 0, '', '', 0, 4964403, 1, 1, 0, '0000-00-00 00:00:00', 1, NULL, '', '', '', '', '', '', '', '', '', '', ''),
(61, 5, 0, 'IMGP1737', 'imgp1737', 'PhongTruyenThong/IMGP1737.JPG', NULL, '2010-08-25 14:13:39', 0, '', '', 0, '', NULL, 0, 4523982, 1, 1, 0, '0000-00-00 00:00:00', 2, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', ''),
(62, 5, 0, 'IMGP1874', 'imgp1874', 'PhongTruyenThong/IMGP1874.JPG', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt. (Ảnh: Làng Hòa Bình)</p>', '2010-08-25 14:13:39', 0, '', '', 0, '', '', 0, 5213114, 1, 1, 0, '0000-00-00 00:00:00', 3, NULL, '', '', '', '', '', '', '', '', '', '', ''),
(63, 5, 0, 'P1000483', 'p1000483', 'PhongTruyenThong/P1000483.JPG', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt. (Ảnh: Làng Hòa Bình)</p>', '2010-08-25 14:13:39', 0, '', '', 0, '', '', 0, 1807029, 1, 1, 0, '0000-00-00 00:00:00', 4, NULL, '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_phocagallery_categories`
--

CREATE TABLE IF NOT EXISTS `jos_phocagallery_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `owner_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL DEFAULT '',
  `section` varchar(50) NOT NULL DEFAULT '',
  `image_position` varchar(30) NOT NULL DEFAULT '',
  `description` text,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editor` varchar(50) DEFAULT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `count` int(11) NOT NULL DEFAULT '0',
  `hits` int(11) NOT NULL DEFAULT '0',
  `accessuserid` text,
  `uploaduserid` text,
  `deleteuserid` text,
  `userfolder` text,
  `latitude` varchar(20) NOT NULL DEFAULT '',
  `longitude` varchar(20) NOT NULL DEFAULT '',
  `zoom` int(3) NOT NULL DEFAULT '0',
  `geotitle` varchar(255) NOT NULL DEFAULT '',
  `extid` varchar(255) NOT NULL DEFAULT '',
  `exta` varchar(255) NOT NULL DEFAULT '',
  `extu` varchar(255) NOT NULL DEFAULT '',
  `extauth` varchar(255) NOT NULL DEFAULT '',
  `params` text,
  `metakey` text,
  `metadesc` text,
  PRIMARY KEY (`id`),
  KEY `cat_idx` (`section`,`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `jos_phocagallery_categories`
--

INSERT INTO `jos_phocagallery_categories` (`id`, `parent_id`, `owner_id`, `title`, `name`, `alias`, `image`, `section`, `image_position`, `description`, `date`, `published`, `approved`, `checked_out`, `checked_out_time`, `editor`, `ordering`, `access`, `count`, `hits`, `accessuserid`, `uploaduserid`, `deleteuserid`, `userfolder`, `latitude`, `longitude`, `zoom`, `geotitle`, `extid`, `exta`, `extu`, `extauth`, `params`, `metakey`, `metadesc`) VALUES
(1, 0, 0, 'Ảnh hoạt động', '', 'anh-hoat-dong', '', '', 'left', '', '2010-08-17 15:57:19', 1, 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, 44, '0', '-2', '-2', '', '', '', 0, '', '', '', '', '', NULL, '', ''),
(2, 0, 0, 'Ảnh sự kiện', '', 'anh-su-kien', '', '', 'left', '<p><span class="email">Sự kiện: Điều trị cho các trẻ em dị tật Campuchia - Ngày 23/09/2009</span><br />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', '2010-08-17 15:57:32', 1, 1, 0, '0000-00-00 00:00:00', NULL, 2, 0, 0, 151, '0', '-2', '-2', '', '', '', 0, '', '', '', '', '', NULL, '', ''),
(3, 0, 0, 'Ảnh truyền thống', '', 'anh-truyen-thong', '', '', 'left', '<p><span class="email">Truyền thống - Ngày 23/09/1999</span><br />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', '2010-08-17 15:57:42', 1, 1, 0, '0000-00-00 00:00:00', NULL, 3, 0, 0, 70, '0', '-2', '-2', '', '', '', 0, '', '', '', '', '', NULL, '', ''),
(4, 1, 0, 'Vui chơi đá banh', '', 'vui-choi-da-banh', '', '', 'left', '<p><span class="email">Vui chơi đá banh - Ngày 23/09/2019</span><br />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', '2010-08-17 16:01:10', 1, 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, 19, '0', '-2', '-2', '', '', '', 0, '', '', '', '', '', NULL, '', ''),
(5, 1, 0, 'Vui Xuân Kỷ Sửu - Cà Mau', '', 'vui-xuan-ky-suu-ca-mau', '', '', 'left', '<p><span class="email">Vui Xuân Kỷ Sửu - Cà Mau</span><br />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', '2010-08-17 16:02:35', 1, 1, 0, '0000-00-00 00:00:00', NULL, 4, 0, 0, 5, '0', '-2', '-2', '', '', '', 0, '', '', '', '', '', NULL, '', ''),
(6, 2, 0, 'Văn nghệ - Múa Nhật Bản', '', 'van-nghe-mua-nhat-ban', '', '', 'left', '<p><span class="email">Đoàn múa Nhật Bản - 27 / 09 / 2008</span><br />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', '2010-08-17 16:03:14', 1, 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, 115, '0', '-2', '-2', '', '', '', 0, '', '', '', '', '', NULL, '', ''),
(7, 2, 0, 'Á Hậu Lưu Bảo Anh', '', 'a-hau-luu-bao-anh-', '', '', 'left', '<p><span class="email">Sự kiện : Á Hậu Lưu Bảo Anh đến thăm Làng - Ngày 23/09/2009</span><br />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', '2010-08-17 16:03:38', 1, 1, 0, '0000-00-00 00:00:00', NULL, 2, 0, 0, 12, '0', '-2', '-2', '', '', '', 0, '', '', '', '', '', NULL, '', ''),
(8, 3, 0, 'Truyền thống 1', '', 'truyen-thong-1', '', '', 'left', '<p><span class="email">Truyền thống - Ngày 23/09/1998</span><br />Lorem ipsum  dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor  incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,  quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo  consequat.</p>', '2010-08-17 16:03:52', 1, 1, 0, '0000-00-00 00:00:00', NULL, 4, 0, 0, 3, '0', '-2', '-2', '', '', '', 0, '', '', '', '', '', NULL, '', ''),
(9, 3, 0, 'Truyền thống 2', '', 'truyen-thong-2', '', '', 'left', '<p><span class="email">Truyền thống - Ngày 23/09/1999</span><br />Lorem ipsum  dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor  incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,  quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo  consequat.</p>', '2010-08-17 16:04:12', 1, 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, 9, '0', '-2', '-2', '', '', '', 0, '', '', '', '', '', NULL, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_phocagallery_comments`
--

CREATE TABLE IF NOT EXISTS `jos_phocagallery_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `title` varchar(255) NOT NULL DEFAULT '',
  `comment` text,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_phocagallery_comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_phocagallery_img_comments`
--

CREATE TABLE IF NOT EXISTS `jos_phocagallery_img_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `imgid` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `title` varchar(255) NOT NULL DEFAULT '',
  `comment` text,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_phocagallery_img_comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_phocagallery_img_votes`
--

CREATE TABLE IF NOT EXISTS `jos_phocagallery_img_votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `imgid` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `rating` tinyint(1) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_phocagallery_img_votes`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_phocagallery_img_votes_statistics`
--

CREATE TABLE IF NOT EXISTS `jos_phocagallery_img_votes_statistics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `imgid` int(11) NOT NULL DEFAULT '0',
  `count` int(11) NOT NULL DEFAULT '0',
  `average` float(8,6) NOT NULL DEFAULT '0.000000',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_phocagallery_img_votes_statistics`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_phocagallery_user`
--

CREATE TABLE IF NOT EXISTS `jos_phocagallery_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL DEFAULT '0',
  `avatar` varchar(40) NOT NULL DEFAULT '',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_phocagallery_user`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_phocagallery_votes`
--

CREATE TABLE IF NOT EXISTS `jos_phocagallery_votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `rating` tinyint(1) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_phocagallery_votes`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_phocagallery_votes_statistics`
--

CREATE TABLE IF NOT EXISTS `jos_phocagallery_votes_statistics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL DEFAULT '0',
  `count` int(11) NOT NULL DEFAULT '0',
  `average` float(8,6) NOT NULL DEFAULT '0.000000',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_phocagallery_votes_statistics`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_plugins`
--

CREATE TABLE IF NOT EXISTS `jos_plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `element` varchar(100) NOT NULL DEFAULT '',
  `folder` varchar(100) NOT NULL DEFAULT '',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `published` tinyint(3) NOT NULL DEFAULT '0',
  `iscore` tinyint(3) NOT NULL DEFAULT '0',
  `client_id` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_folder` (`published`,`client_id`,`access`,`folder`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=49 ;

--
-- Dumping data for table `jos_plugins`
--

INSERT INTO `jos_plugins` (`id`, `name`, `element`, `folder`, `access`, `ordering`, `published`, `iscore`, `client_id`, `checked_out`, `checked_out_time`, `params`) VALUES
(1, 'Authentication - Joomla', 'joomla', 'authentication', 0, 1, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(2, 'Authentication - LDAP', 'ldap', 'authentication', 0, 2, 0, 1, 0, 0, '0000-00-00 00:00:00', 'host=\nport=389\nuse_ldapV3=0\nnegotiate_tls=0\nno_referrals=0\nauth_method=bind\nbase_dn=\nsearch_string=\nusers_dn=\nusername=\npassword=\nldap_fullname=fullName\nldap_email=mail\nldap_uid=uid\n\n'),
(3, 'Authentication - GMail', 'gmail', 'authentication', 0, 4, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(4, 'Authentication - OpenID', 'openid', 'authentication', 0, 3, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(5, 'User - Joomla!', 'joomla', 'user', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', 'autoregister=1\n\n'),
(6, 'Search - Content', 'content', 'search', 0, 1, 1, 1, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\nsearch_content=1\nsearch_uncategorised=1\nsearch_archived=1\n\n'),
(7, 'Search - Contacts', 'contacts', 'search', 0, 3, 1, 1, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(8, 'Search - Categories', 'categories', 'search', 0, 4, 1, 0, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(9, 'Search - Sections', 'sections', 'search', 0, 5, 1, 0, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(10, 'Search - Newsfeeds', 'newsfeeds', 'search', 0, 6, 1, 0, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(11, 'Search - Weblinks', 'weblinks', 'search', 0, 2, 1, 1, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(12, 'Content - Pagebreak', 'pagebreak', 'content', 0, 10000, 1, 1, 0, 0, '0000-00-00 00:00:00', 'enabled=1\ntitle=1\nmultipage_toc=1\nshowall=1\n\n'),
(13, 'Content - Rating', 'vote', 'content', 0, 4, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(14, 'Content - Email Cloaking', 'emailcloak', 'content', 0, 5, 1, 0, 0, 0, '0000-00-00 00:00:00', 'mode=1\n\n'),
(15, 'Content - Code Hightlighter (GeSHi)', 'geshi', 'content', 0, 5, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(16, 'Content - Load Module', 'loadmodule', 'content', 0, 6, 1, 0, 0, 0, '0000-00-00 00:00:00', 'enabled=1\nstyle=xhtml\n\n'),
(17, 'Content - Page Navigation', 'pagenavigation', 'content', 0, 2, 1, 1, 0, 0, '0000-00-00 00:00:00', 'position=1\n\n'),
(18, 'Editor - No Editor', 'none', 'editors', 0, 0, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(19, 'Editor - TinyMCE', 'tinymce', 'editors', 0, 0, 1, 1, 0, 0, '0000-00-00 00:00:00', 'mode=extended\nskin=0\ncompressed=0\ncleanup_startup=0\ncleanup_save=2\nentity_encoding=raw\nlang_mode=0\nlang_code=en\ntext_direction=ltr\ncontent_css=1\ncontent_css_custom=\nrelative_urls=1\nnewlines=0\ninvalid_elements=applet\nextended_elements=\ntoolbar=top\ntoolbar_align=left\nhtml_height=550\nhtml_width=750\nelement_path=1\nfonts=1\npaste=1\nsearchreplace=1\ninsertdate=1\nformat_date=%Y-%m-%d\ninserttime=1\nformat_time=%H:%M:%S\ncolors=1\ntable=1\nsmilies=1\nmedia=1\nhr=1\ndirectionality=1\nfullscreen=1\nstyle=1\nlayer=1\nxhtmlxtras=1\nvisualchars=1\nnonbreaking=1\nblockquote=1\ntemplate=0\nadvimage=1\nadvlink=1\nautosave=1\ncontextmenu=1\ninlinepopups=1\nsafari=1\ncustom_plugin=\ncustom_button=\n\n'),
(20, 'Editor - XStandard Lite 2.0', 'xstandard', 'editors', 0, 0, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(21, 'Editor Button - Image', 'image', 'editors-xtd', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(22, 'Editor Button - Pagebreak', 'pagebreak', 'editors-xtd', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(23, 'Editor Button - Readmore', 'readmore', 'editors-xtd', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(24, 'XML-RPC - Joomla', 'joomla', 'xmlrpc', 0, 7, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(25, 'XML-RPC - Blogger API', 'blogger', 'xmlrpc', 0, 7, 0, 1, 0, 0, '0000-00-00 00:00:00', 'catid=1\nsectionid=0\n\n'),
(27, 'System - SEF', 'sef', 'system', 0, 1, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(28, 'System - Debug', 'debug', 'system', 0, 2, 1, 0, 0, 0, '0000-00-00 00:00:00', 'queries=1\nmemory=1\nlangauge=1\n\n'),
(29, 'System - Legacy', 'legacy', 'system', 0, 3, 0, 1, 0, 0, '0000-00-00 00:00:00', 'route=0\n\n'),
(30, 'System - Cache', 'cache', 'system', 0, 4, 0, 1, 0, 0, '0000-00-00 00:00:00', 'browsercache=0\ncachetime=15\n\n'),
(31, 'System - Log', 'log', 'system', 0, 5, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(32, 'System - Remember Me', 'remember', 'system', 0, 6, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(33, 'System - Backlink', 'backlink', 'system', 0, 7, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(34, 'Content - Joomla Imagesized Plugin', 'plg_imagesized', 'content', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', 'enabled=1\nsized_img_article=1\nexpire=30\nquality=90\nar_width=400\nar_height=400\nar_remove_link=1\nar_link2originalimage=1\nextra_link2originalimage=\nexcluded_images=\nar_remove_img_tag=style:class\nicl_exc_catsect=0\nsectionid_list=x\ncatid_list=3,4\nitemid_list=15\nonly_frontpage=t\nfp_image_link=1\nfp_remove_class=1\nfp_default_image=plugins/content/imagesresizecache/blank.png\nfp_used_default_image=1\nextra_class=\nfp_width_l=240\nfp_height_l=160\nfp_align_l=left\nfp_position_l=0\nfp_textalign_l=justify\nfp_width=105\nfp_height=105\nfp_advanced_config=\nfp_frcolor=#ffffff\nfp_bocolor=#a0a0a0\nfp_vspace=0\nfp_hspace=6\nfp_chars_l=250\nfp_chars=300\nfp_more=\nallowed_tags=\nfp_align=left\nfp_position=0\nfp_textalign=justify\n\n'),
(37, 'AllVideos (by JoomlaWorks)', 'jw_allvideos', 'content', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', 'gzipScripts=0\nvfolder=images/stories/videos\nvwidth=400\nvheight=300\ntransparency=transparent\nbackground=#54d2f6\nbackgroundQT=navy\ncontrolBarLocation=bottom\nlightboxLink=0\nlightboxWidth=800\nlightboxHeight=600\nafolder=images/stories/audio\nawidth=300\naheight=20\nautoplay=0\ndownloadLink=0\nembedForm=0\ndebugMode=0\n\n'),
(42, 'JA Tabs for Joomla! 1.5', 'ja_tabs', 'content', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', 'style=default\n\n'),
(43, 'System - JA Map', 'plg_jamap', 'system', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', 'api_key=ABQIAAAAxKmbifV6O2qG7YZIB20VaxS317Nuqfg3JldWbtt8q3eJXm014BQAKTE4CCzmfnv3pB4CED3ZPtFgyg\ndisable_map=0\nto_location=Ho Chi Minh\ntarget_lat=\ntarget_lon=\nto_location_info=\nfrom_location=\nmaptype=normal\nmap_width=500\nmap_height=300\nzoom=15\nmaptype_control_display=1\nmaptype_control_style=drop_down\nmaptype_control_position=top_right\ntoolbar_control_display=1\ntoolbar_control_style=small_3d\ntoolbar_control_position=top_left\ndisplay_layer=none\ndisplay_popup=0\npopup_width=640\npopup_height=480\npopup_type=highslide\ndisplay_scale=0\ndisplay_overview=0\nsensor=0\ncode_container={jamap }\n\n'),
(44, 'Content - JA Comment', 'jacomment', 'content', 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 'postion_add_button=3\ncatsid=5\nmenusid=10\ndisplay_comment_link=1\ndisplay_comment_count=1\n\n'),
(45, 'System - JA Comment', 'jacomment', 'system', 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 'display_comment_link=1\ndisplay_comment_count=1\n'),
(46, 'Custom Properties Tags', 'cptags', 'content', 0, 1, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(47, 'Search - CP Tags', 'cptags', 'search', 0, 1, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(48, 'Custom Properties Tags Button', 'cptags', 'editors-xtd', 0, 1, 1, 0, 0, 0, '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_polls`
--

CREATE TABLE IF NOT EXISTS `jos_polls` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `voters` int(9) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `access` int(11) NOT NULL DEFAULT '0',
  `lag` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_polls`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_poll_data`
--

CREATE TABLE IF NOT EXISTS `jos_poll_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pollid` int(11) NOT NULL DEFAULT '0',
  `text` text NOT NULL,
  `hits` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pollid` (`pollid`,`text`(1))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_poll_data`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_poll_date`
--

CREATE TABLE IF NOT EXISTS `jos_poll_date` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `vote_id` int(11) NOT NULL DEFAULT '0',
  `poll_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `poll_id` (`poll_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_poll_date`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_poll_menu`
--

CREATE TABLE IF NOT EXISTS `jos_poll_menu` (
  `pollid` int(11) NOT NULL DEFAULT '0',
  `menuid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pollid`,`menuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_poll_menu`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_sections`
--

CREATE TABLE IF NOT EXISTS `jos_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` text NOT NULL,
  `scope` varchar(50) NOT NULL DEFAULT '',
  `image_position` varchar(30) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `count` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_scope` (`scope`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `jos_sections`
--

INSERT INTO `jos_sections` (`id`, `title`, `name`, `alias`, `image`, `scope`, `image_position`, `description`, `published`, `checked_out`, `checked_out_time`, `ordering`, `access`, `count`, `params`) VALUES
(1, 'Tin tức', '', 'tin-tuc', '', 'content', 'left', '', 1, 0, '0000-00-00 00:00:00', 1, 0, 8, ''),
(2, 'Video Clips', '', 'video-clips', '', 'content', 'left', '', 1, 0, '0000-00-00 00:00:00', 2, 0, 2, ''),
(3, 'Liên hệ', '', 'lien-he', '', 'content', 'left', '', 1, 0, '0000-00-00 00:00:00', 3, 0, 0, ''),
(4, 'Khác', '', 'khac', '', 'content', 'left', '', 1, 0, '0000-00-00 00:00:00', 4, 0, 3, ''),
(5, 'Slideshow', '', 'slideshow', '', 'content', 'left', '', 1, 0, '0000-00-00 00:00:00', 5, 0, 2, ''),
(6, 'Hòa Bình', '', 'hoa-binh', '', 'content', 'left', '', 1, 0, '0000-00-00 00:00:00', 6, 0, 7, ''),
(7, 'Hệ thống', '', 'he-thong', '', 'content', 'left', '', 1, 0, '0000-00-00 00:00:00', 7, 0, 3, '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_session`
--

CREATE TABLE IF NOT EXISTS `jos_session` (
  `username` varchar(150) DEFAULT '',
  `time` varchar(14) DEFAULT '',
  `session_id` varchar(200) NOT NULL DEFAULT '0',
  `guest` tinyint(4) DEFAULT '1',
  `userid` int(11) DEFAULT '0',
  `usertype` varchar(50) DEFAULT '',
  `gid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `client_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `data` longtext,
  PRIMARY KEY (`session_id`(64)),
  KEY `whosonline` (`guest`,`usertype`),
  KEY `userid` (`userid`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_session`
--

INSERT INTO `jos_session` (`username`, `time`, `session_id`, `guest`, `userid`, `usertype`, `gid`, `client_id`, `data`) VALUES
('admin', '1283025290', '59f8858223fdf71ab079fb31206536cf', 0, 62, 'Super Administrator', 25, 1, '__default|a:8:{s:15:"session.counter";i:152;s:19:"session.timer.start";i:1283023778;s:18:"session.timer.last";i:1283025290;s:17:"session.timer.now";i:1283025290;s:22:"session.client.browser";s:95:"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.6; en-US; rv:1.9.2.8) Gecko/20100722 Firefox/3.6.8";s:8:"registry";O:9:"JRegistry":3:{s:17:"_defaultNameSpace";s:7:"session";s:9:"_registry";a:6:{s:7:"session";a:1:{s:4:"data";O:8:"stdClass":0:{}}s:11:"application";a:1:{s:4:"data";O:8:"stdClass":1:{s:4:"lang";s:0:"";}}s:11:"com_content";a:1:{s:4:"data";O:8:"stdClass":8:{s:23:"viewcontentfilter_order";s:12:"section_name";s:27:"viewcontentfilter_order_Dir";s:0:"";s:23:"viewcontentfilter_state";s:0:"";s:16:"viewcontentcatid";i:19;s:26:"viewcontentfilter_authorid";i:0;s:27:"viewcontentfilter_sectionid";i:6;s:17:"viewcontentsearch";s:0:"";s:21:"viewcontentlimitstart";i:0;}}s:6:"global";a:1:{s:4:"data";O:8:"stdClass":1:{s:4:"list";O:8:"stdClass":1:{s:5:"limit";i:20;}}}s:14:"articleelement";a:1:{s:4:"data";O:8:"stdClass":6:{s:12:"filter_order";s:0:"";s:16:"filter_order_Dir";s:0:"";s:5:"catid";i:15;s:16:"filter_sectionid";i:6;s:10:"limitstart";i:0;s:6:"search";s:0:"";}}s:9:"com_menus";a:1:{s:4:"data";O:8:"stdClass":1:{s:8:"menutype";s:8:"mainmenu";}}}s:7:"_errors";a:0:{}}s:4:"user";O:5:"JUser":19:{s:2:"id";s:2:"62";s:4:"name";s:13:"Administrator";s:8:"username";s:5:"admin";s:5:"email";s:13:"thtinh@vxg.vn";s:8:"password";s:65:"1f7da7caf1176e0cca20fd515ecc1d1c:FXtP5MmKNmeyrZGtYGNTHoCz7NCYVvRI";s:14:"password_clear";s:0:"";s:8:"usertype";s:19:"Super Administrator";s:5:"block";s:1:"0";s:9:"sendEmail";s:1:"1";s:3:"gid";s:2:"25";s:12:"registerDate";s:19:"2010-07-02 07:28:55";s:13:"lastvisitDate";s:19:"2010-08-28 18:29:16";s:10:"activation";s:0:"";s:6:"params";s:0:"";s:3:"aid";i:2;s:5:"guest";i:0;s:7:"_params";O:10:"JParameter":7:{s:4:"_raw";s:0:"";s:4:"_xml";N;s:9:"_elements";a:0:{}s:12:"_elementPath";a:1:{i:0;s:62:"/Users/thtinh/Sites/hb/libraries/joomla/html/parameter/element";}s:17:"_defaultNameSpace";s:8:"_default";s:9:"_registry";a:1:{s:8:"_default";a:1:{s:4:"data";O:8:"stdClass":0:{}}}s:7:"_errors";a:0:{}}s:9:"_errorMsg";N;s:7:"_errors";a:0:{}}s:13:"session.token";s:32:"e087e4d2bfe831002ed62002e4229aa6";}'),
('', '1283025444', 'c4d93bda8f071692333b75eed23afc05', 1, 0, '', 0, 0, '__default|a:7:{s:15:"session.counter";i:48;s:19:"session.timer.start";i:1283021139;s:18:"session.timer.last";i:1283025299;s:17:"session.timer.now";i:1283025444;s:22:"session.client.browser";s:95:"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.6; en-US; rv:1.9.2.8) Gecko/20100722 Firefox/3.6.8";s:8:"registry";O:9:"JRegistry":3:{s:17:"_defaultNameSpace";s:7:"session";s:9:"_registry";a:1:{s:7:"session";a:1:{s:4:"data";O:8:"stdClass":0:{}}}s:7:"_errors";a:0:{}}s:4:"user";O:5:"JUser":19:{s:2:"id";i:0;s:4:"name";N;s:8:"username";N;s:5:"email";N;s:8:"password";N;s:14:"password_clear";s:0:"";s:8:"usertype";N;s:5:"block";N;s:9:"sendEmail";i:0;s:3:"gid";i:0;s:12:"registerDate";N;s:13:"lastvisitDate";N;s:10:"activation";N;s:6:"params";N;s:3:"aid";i:0;s:5:"guest";i:1;s:7:"_params";O:10:"JParameter":7:{s:4:"_raw";s:0:"";s:4:"_xml";N;s:9:"_elements";a:0:{}s:12:"_elementPath";a:1:{i:0;s:62:"/Users/thtinh/Sites/hb/libraries/joomla/html/parameter/element";}s:17:"_defaultNameSpace";s:8:"_default";s:9:"_registry";a:1:{s:8:"_default";a:1:{s:4:"data";O:8:"stdClass":0:{}}}s:7:"_errors";a:0:{}}s:9:"_errorMsg";N;s:7:"_errors";a:0:{}}}');

-- --------------------------------------------------------

--
-- Table structure for table `jos_stats_agents`
--

CREATE TABLE IF NOT EXISTS `jos_stats_agents` (
  `agent` varchar(255) NOT NULL DEFAULT '',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hits` int(11) unsigned NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_stats_agents`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_templates_menu`
--

CREATE TABLE IF NOT EXISTS `jos_templates_menu` (
  `template` varchar(255) NOT NULL DEFAULT '',
  `menuid` int(11) NOT NULL DEFAULT '0',
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`menuid`,`client_id`,`template`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_templates_menu`
--

INSERT INTO `jos_templates_menu` (`template`, `menuid`, `client_id`) VALUES
('vxg_hb', 0, 0),
('khepri', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `jos_users`
--

CREATE TABLE IF NOT EXISTS `jos_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(150) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `usertype` varchar(25) NOT NULL DEFAULT '',
  `block` tinyint(4) NOT NULL DEFAULT '0',
  `sendEmail` tinyint(4) DEFAULT '0',
  `gid` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `registerDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastvisitDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activation` varchar(100) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `usertype` (`usertype`),
  KEY `idx_name` (`name`),
  KEY `gid_block` (`gid`,`block`),
  KEY `username` (`username`),
  KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=64 ;

--
-- Dumping data for table `jos_users`
--

INSERT INTO `jos_users` (`id`, `name`, `username`, `email`, `password`, `usertype`, `block`, `sendEmail`, `gid`, `registerDate`, `lastvisitDate`, `activation`, `params`) VALUES
(62, 'Administrator', 'admin', 'thtinh@vxg.vn', '1f7da7caf1176e0cca20fd515ecc1d1c:FXtP5MmKNmeyrZGtYGNTHoCz7NCYVvRI', 'Super Administrator', 0, 1, 25, '2010-07-02 07:28:55', '2010-08-28 19:31:23', '', ''),
(63, 'hoabinh', 'hoabinh', 'info@hoabinhvillage.org', '67b9fe25fd0f49da6433d09f1ddd8083:Bq3TiKweUxH2A6g3dybZJR0N8qHsr00f', 'Administrator', 0, 0, 24, '2010-07-13 07:51:33', '2010-07-13 07:52:29', '', 'admin_language=\nlanguage=\neditor=\nhelpsite=\ntimezone=0\n\n');

-- --------------------------------------------------------

--
-- Table structure for table `jos_weblinks`
--

CREATE TABLE IF NOT EXISTS `jos_weblinks` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL DEFAULT '0',
  `sid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(250) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hits` int(11) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`,`published`,`archived`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_weblinks`
--

